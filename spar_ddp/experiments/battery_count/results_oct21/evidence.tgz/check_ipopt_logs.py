import sys,re,math,json
s=open(sys.argv[1]).read(); table=open(sys.argv[2]).read()
kv=lambda s:dict(re.findall(r'(\w+)=([^\s]+)',s))
trace=[kv(x) for x in s.splitlines() if x.startswith('IPOPT_ITER ')]
assert trace and re.search(r'CENTRAL_IPOPT .*status=LOCALLY_SOLVED',s)
# Warm-up output can precede the timed table; retain the last occurrence.
original={}
for line in table.splitlines():
 m=re.match(r'^\s*(\d+)r?\s+([-0-9.]+e[-+]\d+)\s+([0-9.]+e[-+]\d+)\s',line)
 if m:original[int(m[1])]=float(m[3])
assert all(int(d['iteration']) in original for d in trace),'Missing original-constraint iteration table rows'
assert all(math.isfinite(float(d[k])) for d in trace for k in ('objective','inf_pr','inf_du','elapsed_s'))
assert all(float(b['elapsed_s'])>=float(a['elapsed_s']) for a,b in zip(trace,trace[1:]))
print(json.dumps(dict(logging_validated=True,callback_rows=len(trace),original_iteration_rows=len(original),original_source='Ipopt original-constraint table; printed precision retained')))
