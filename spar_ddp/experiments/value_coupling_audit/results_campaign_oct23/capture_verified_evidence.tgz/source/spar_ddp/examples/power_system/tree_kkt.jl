# Block-tree elimination of a FilterDDP stage KKT on a radial network: the
# hand-written counterpart of MUMPS's Schur complement onto the battery rows
# (spar_ddp/notes/PARALLEL_IN_TIME.md, Section 4).
#
# The stage KKT K = [H cu'; cu 0] of ieee123c_filterddp.jl groups naturally by
# bus: a non-root bus j owns its incoming line's P, Q, ell, SOC slack, its
# voltage v_j, its DER control, and its own P-balance, Q-balance, voltage-drop
# and SOC rows. Those groups couple only to the parent bus and the children
# (checked against K's pattern when the layout is built), so eliminating the
# groups from the leaves to the substation is block Gaussian elimination on
# the feeder tree: every elimination is a small dense LU (~10 unknowns) and
# passes a 3x3 update to the parent. What is kept is E = {battery powers,
# energy rows}; the energy slacks couple only to E and are eliminated exactly
# on their own. The Schur complement onto E is
#     S = K_EE - K_E,Fc * Ninv[Fc, Fc] * K_Fc,E - K_E,iso * inv(K_iso) * K_iso,E,
# where N is the network part, Fc the network rows coupled to E (the
# P-balance rows of battery buses), and Ninv[Fc, Fc] is obtained by one sweep
# up the battery paths and one sweep down the union of those paths.

using LinearAlgebra, SparseArrays

struct TreeKKTLayout
    n::Int
    root::Int
    post::Vector{Int}                  # nodes, children before parent, root last
    parent::Vector{Int}                # 0 for the root
    children::Vector{Vector{Int}}
    own::Vector{Vector{Int}}           # K indices eliminated at each node
    iface::Vector{Vector{Int}}         # K indices of the parent coupled to own
    iface_pos::Vector{Vector{Int}}     # their positions in the parent's own
    E::Vector{Int}                     # kept: battery powers, energy rows
    iso::Vector{Int}                   # energy slacks (coupled only to E)
    Fc::Vector{Int}                    # network indices coupled to E
    own_Fc::Vector{Vector{Int}}        # per node: positions in Fc of its own Fc indices
    own_Fc_pos::Vector{Vector{Int}}    # ... and their positions in own
    cols::Vector{Vector{Int}}          # per node: Fc positions in its subtree, block order
    # nzval positions for the dense local blocks (pattern is fixed)
    oo::Vector{Vector{NTuple{3,Int}}}  # (row, col, nz) within own x own
    oi::Vector{Vector{NTuple{3,Int}}}  # own x iface
end

# K index -> owner: node id (> 0), -1 for E, -2 for iso.
function tree_kkt_layout(data, idx, nu::Int, K::SparseMatrixCSC)
    buses, lines, nonroot = data[:Nset], data[:Lset], data[:Nm1set]
    rootbus = data[:substationBus]
    N, L, nB = length(buses), length(lines), length(data[:Bset])
    buspos = Dict(j => k for (k, j) in enumerate(buses))
    linepos = Dict(e => k for (k, e) in enumerate(lines))
    derpos = Dict(j => k for (k, j) in enumerate(data[:Dset]))
    n = size(K, 1)
    root = buspos[rootbus]
    own = [Int[] for _ in 1:N]
    # Rows follow `equations` in ieee123c_filterddp.jl: P balance (root, then
    # nonroot), Q balance (root, nonroot), voltage drop and SOC per line, root
    # voltage, energy per battery.
    append!(own[root], [idx.ps, idx.qs, idx.v[root], nu + 1, nu + N + 1, nu + 2N + 2L + 1])
    for (k, j) in enumerate(nonroot)
        b = buspos[j]
        e = linepos[(data[:parent][j], j)]
        append!(own[b], [idx.P[e], idx.Q[e], idx.ell[e], idx.soc_slack[e], idx.v[b],
                         nu + 1 + k, nu + N + 1 + k, nu + 2N + e, nu + 2N + L + e])
    end
    for (d, j) in enumerate(data[:Dset])
        push!(own[buspos[j]], idx.qnorm[d])
    end
    E = vcat(collect(idx.pb), [nu + 2N + 2L + 1 + b for b in 1:nB])
    iso = collect(idx.energy_slack)

    owner = zeros(Int, n)
    for j in 1:N, i in own[j]
        owner[i] == 0 || error("index $i assigned twice")
        owner[i] = j
    end
    for i in E; owner[i] == 0 || error("E index $i assigned twice"); owner[i] = -1; end
    for i in iso; owner[i] == 0 || error("iso index $i assigned twice"); owner[i] = -2; end
    all(!=(0), owner) || error("$(count(==(0), owner)) K indices not assigned to any block")

    parent = zeros(Int, N)
    children = [Int[] for _ in 1:N]
    for j in nonroot
        b, p = buspos[j], buspos[data[:parent][j]]
        parent[b] = p
        push!(children[p], b)
    end
    # Post-order without recursion.
    post = Int[]; stack = [(root, false)]
    while !isempty(stack)
        j, done = pop!(stack)
        if done
            push!(post, j)
        else
            push!(stack, (j, true))
            for c in children[j]; push!(stack, (c, false)); end
        end
    end

    # Interfaces, and a check that the pattern really is a block tree.
    rows = rowvals(K)
    iface = [Int[] for _ in 1:N]
    for j in 1:N, c in own[j], p in nzrange(K, c)
        i = rows[p]; o = owner[i]
        if o > 0 && o != j
            if o == parent[j]
                push!(iface[j], i)
            elseif parent[o] != j
                error("K couples node $j to node $o, which is neither parent nor child")
            end
        elseif o == -2
            error("energy slack $i couples to the network")
        end
    end
    for i in iso, p in nzrange(K, i)
        owner[rows[p]] in (-1, -2) || error("energy slack $i couples outside E")
    end
    iface = [sort!(unique(v)) for v in iface]
    ownpos = [Dict(i => t for (t, i) in enumerate(own[j])) for j in 1:N]
    iface_pos = [j == root ? Int[] : [ownpos[parent[j]][i] for i in iface[j]] for j in 1:N]

    # Network indices coupled to E.
    isE = falses(n); isE[E] .= true
    Fc = Int[]
    for c in E, p in nzrange(K, c)
        i = rows[p]
        owner[i] > 0 && push!(Fc, i)
    end
    Fc = sort!(unique(Fc))
    Fcpos = Dict(i => t for (t, i) in enumerate(Fc))
    own_Fc = [Int[] for _ in 1:N]; own_Fc_pos = [Int[] for _ in 1:N]
    for i in Fc
        j = owner[i]
        push!(own_Fc[j], Fcpos[i]); push!(own_Fc_pos[j], ownpos[j][i])
    end
    cols = [Int[] for _ in 1:N]
    for j in post
        cols[j] = vcat(own_Fc[j], (cols[c] for c in children[j])...)
    end

    # nzval positions of the local blocks.
    oo = [NTuple{3,Int}[] for _ in 1:N]
    oi = [NTuple{3,Int}[] for _ in 1:N]
    for j in 1:N
        ipos = Dict(i => t for (t, i) in enumerate(iface[j]))
        for (tc, c) in enumerate(own[j]), p in nzrange(K, c)
            i = rows[p]
            if owner[i] == j
                push!(oo[j], (ownpos[j][i], tc, p))
            elseif haskey(ipos, i)
                push!(oi[j], (tc, ipos[i], p))      # K[i, c], i in iface: stored as (own col, iface row)
            end
        end
    end
    return TreeKKTLayout(n, root, post, parent, children, own, iface, iface_pos,
                         E, iso, Fc, own_Fc, own_Fc_pos, cols, oo, oi)
end

# Dense LU with partial pivoting for the ~10x10 node blocks, in plain Julia:
# LAPACK/OpenBLAS calls on blocks this small cost far more in call and
# threading overhead than in arithmetic (~68 us per bus at large10k).
struct SmallLU
    A::Matrix{Float64}                # unit L below the diagonal, U on and above
    perm::Vector{Int}                 # row i of the factored matrix = row perm[i] of the original
end

function smalllu!(A::Matrix{Float64})
    n = size(A, 1); perm = collect(1:n)
    @inbounds for k in 1:n
        p = k; amax = abs(A[k, k])
        for i in k+1:n
            a = abs(A[i, k]); a > amax && (amax = a; p = i)
        end
        amax == 0 && throw(SingularException(k))
        if p != k
            for jj in 1:n; A[k, jj], A[p, jj] = A[p, jj], A[k, jj]; end
            perm[k], perm[p] = perm[p], perm[k]
        end
        inv_d = 1 / A[k, k]
        for i in k+1:n
            l = A[i, k] * inv_d
            A[i, k] = l
            l == 0 && continue
            for jj in k+1:n; A[i, jj] -= l * A[k, jj]; end
        end
    end
    return SmallLU(A, perm)
end

function Base.:\(F::SmallLU, B::AbstractMatrix)
    A = F.A; n = size(A, 1); w = size(B, 2)
    X = Matrix{Float64}(undef, n, w)
    @inbounds for c in 1:w
        for i in 1:n; X[i, c] = B[F.perm[i], c]; end
        for i in 2:n
            s = X[i, c]
            for k in 1:i-1; s -= A[i, k] * X[k, c]; end
            X[i, c] = s
        end
        for i in n:-1:1
            s = X[i, c]
            for k in i+1:n; s -= A[i, k] * X[k, c]; end
            X[i, c] = s / A[i, i]
        end
    end
    return X
end

# Small dense product without BLAS, for the same reason.
function smallmul(A::AbstractMatrix, B::AbstractMatrix)
    m, k = size(A); w = size(B, 2)
    C = zeros(m, w)
    @inbounds for c in 1:w, kk in 1:k
        b = B[kk, c]
        b == 0 && continue
        for i in 1:m; C[i, c] += A[i, kk] * b; end
    end
    return C
end

struct TreeKKTFactor
    F::Vector{SmallLU}                # LU of each node's own block
    W::Vector{Matrix{Float64}}        # A_oo \ A_oi
    Aio::Vector{Matrix{Float64}}      # A_io (iface x own)
    Mroot::Matrix{Float64}            # the root block with all contributions, unfactored
end

# Opt-in ablation backend: same battery interface and exact-curvature path,
# with generic sparse network elimination instead of the radial sweep.
struct SparseNetworkKKTFactor{F}
    factor::F
    network::Vector{Int}
    Mroot::Matrix{Float64}  # unused rank-one placeholder on the exact path
end

const _NETWORK_CAPTURE_COUNT = Ref(0)

function network_kkt_factor(lay, K)
    if haskey(ENV, "TREE_ABLATION_CAPTURE_DIR")
        _NETWORK_CAPTURE_COUNT[] += 1
        if _NETWORK_CAPTURE_COUNT[] == parse(Int, get(ENV, "TREE_ABLATION_CAPTURE_CALL", "1"))
            capture_network_ablation(lay, K)
        end
    end
    backend = get(ENV, "FILTERDDP_NETWORK_BACKEND", "tree")
    backend == "tree" && return tree_kkt_factor(lay, K)
    backend == "umfpack" && return sparse_network_kkt_factor(lay, K)
    error("unknown FILTERDDP_NETWORK_BACKEND=$backend (expected tree or umfpack)")
end

# Block LU from the leaves to the root. K is symmetric, so A_oi = A_io'.
function tree_kkt_factor(lay::TreeKKTLayout, K::SparseMatrixCSC)
    N = length(lay.own)
    nz = nonzeros(K)
    F = Vector{SmallLU}(undef, N)
    W = Vector{Matrix{Float64}}(undef, N)
    Aio = Vector{Matrix{Float64}}(undef, N)
    C = Vector{Matrix{Float64}}(undef, N)
    Mroot = zeros(0, 0)
    for j in lay.post
        m = length(lay.own[j]); q = length(lay.iface[j])
        A = zeros(m, m)
        for (r, c, p) in lay.oo[j]; A[r, c] = nz[p]; end
        for c in lay.children[j]
            pos = lay.iface_pos[c]; Cc = C[c]
            @inbounds for b in eachindex(pos), a in eachindex(pos)
                A[pos[a], pos[b]] += Cc[a, b]
            end
        end
        j == lay.root && (Mroot = copy(A))
        Fj = smalllu!(A)
        F[j] = Fj
        if j != lay.root
            Bio = zeros(q, m)
            for (c, r, p) in lay.oi[j]; Bio[r, c] = nz[p]; end
            Wj = Fj \ Bio'
            W[j] = Wj; Aio[j] = Bio
            Cj = smallmul(Bio, Wj); Cj .*= -1
            C[j] = Cj
        end
    end
    return TreeKKTFactor(F, W, Aio, Mroot)
end

# Ninv[Fc, Fc]: sweep up the battery paths, then down their union.
function tree_kkt_fc_block(lay::TreeKKTLayout, fac::TreeKKTFactor)
    N = length(lay.own); nF = length(lay.Fc)
    Z = Vector{Matrix{Float64}}(undef, N)
    msg = Vector{Matrix{Float64}}(undef, N)
    for j in lay.post
        k = length(lay.cols[j]); k == 0 && continue
        m = length(lay.own[j])
        R = zeros(m, k)
        for (t, pos) in enumerate(lay.own_Fc_pos[j]); R[pos, t] = 1.0; end
        off = length(lay.own_Fc[j])
        for c in lay.children[j]
            kc = length(lay.cols[c]); kc == 0 && continue
            @views R[lay.iface_pos[c], off+1:off+kc] .+= msg[c]
            off += kc
        end
        Zj = fac.F[j] \ R
        Z[j] = Zj
        j != lay.root && (msg[j] = smallmul(fac.Aio[j], Zj) .* -1)
    end
    Y = zeros(nF, nF)
    yroot = zeros(length(lay.own[lay.root]), nF)
    yroot[:, lay.cols[lay.root]] .= Z[lay.root]
    stack = [(lay.root, yroot)]
    while !isempty(stack)
        j, yj = pop!(stack)
        for (t, pos) in zip(lay.own_Fc[j], lay.own_Fc_pos[j])
            @views Y[t, :] .= yj[pos, :]
        end
        for c in lay.children[j]
            isempty(lay.cols[c]) && continue
            yI = yj[lay.iface_pos[c], :]
            yc = smallmul(fac.W[c], yI); yc .*= -1
            @views yc[:, lay.cols[c]] .+= Z[c]
            push!(stack, (c, yc))
        end
    end
    return Y
end

# Schur complement of K onto E, in the order of lay.E.
function tree_kkt_schur(lay::TreeKKTLayout, K::SparseMatrixCSC)
    fac = tree_kkt_factor(lay, K)
    Y = tree_kkt_fc_block(lay, fac)
    KEF = K[lay.E, lay.Fc]                      # sparse: one entry per battery
    S = Matrix(K[lay.E, lay.E])
    S .-= (KEF * Y) * KEF'
    # Each energy slack couples to its own energy row only.
    Epos = Dict(i => t for (t, i) in enumerate(lay.E))
    rows, vals = rowvals(K), nonzeros(K)
    for i in lay.iso
        d = K[i, i]
        nzE = [(Epos[rows[p]], vals[p]) for p in nzrange(K, i) if haskey(Epos, rows[p])]
        for (a, va) in nzE, (b, vb) in nzE
            S[a, b] -= va * vb / d
        end
    end
    return S
end

# ---------------------------------------------------------------- structured --
# The substation (root) is the only place feeders meet, through the 3 root
# unknowns each feeder's top bus couples to. With N the network part, block
# elimination with the root last gives, exactly,
#     Ninv[Fc, Fc] = Bd + Psi * inv(M) * Psi',
# Bd = blockdiag over feeders of the feeder-only inverse, M the root block
# with all feeder contributions, and Psi the feeder rows' response to the
# root unknowns (-1 on root-owned rows). Under the diagonal Hessian K_EE
# couples a battery only to its own energy row, so the Schur complement onto
# E is block diagonal by feeder plus a rank-(root size) term:
#     S = D - U * inv(M) * U',   U = K_E,Fc * Psi,
# and S \ R follows from Woodbury with one small solve per feeder.
#
# Everything that depends only on the sparsity pattern (groups, positions in
# nonzeros(K)) is computed once in TreeKKTStatic.

struct TreeKKTStatic
    feeder::Vector{Int}                       # node -> feeder top (0 for the root)
    gkeys::Vector{Int}                        # group key: feeder top, or -1 for root-coupled E
    perm::Vector{Int}                         # E positions, grouped (permuted order)
    granges::Vector{UnitRange{Int}}           # each group's range in the permuted order
    kee::Vector{Vector{NTuple{3,Int}}}        # per group: (local row, local col, nz) of K_EE
    kef::Vector{NTuple{3,Int}}                # (E pos, Fc pos, nz) of K_E,Fc
    gkef::Vector{Vector{NTuple{3,Int}}}       # per group: (local row, feeder-local Fc col, nz)
    iso_d::Vector{Int}                        # nz of each energy slack's diagonal
    iso_e::Vector{Vector{NTuple{2,Int}}}      # per slack: (E pos, nz)
    giso::Vector{Vector{NTuple{5,Int}}}       # per group: (local a, local b, nz a, nz b, slack)
    colpos::Vector{Dict{Int,Int}}             # per feeder top: Fc pos -> local column
    ooff::Vector{Int}                         # node -> offset of its own block in a flat buffer
    nN::Int
    # Downward sweep: only the rows a node's children and its own Fc entries
    # read are computed (the bus's two balance rows and its voltage).
    need::Vector{Vector{Int}}                 # per node: positions in own
    iface_in_need::Vector{Vector{Int}}        # per node: its iface rows within need[parent]
    fc_in_need::Vector{Vector{Int}}           # per node: its own Fc entries within need
    cidx::Vector{Vector{Int}}                 # per node: feeder-local columns of cols[node]
    depth::Vector{Int}                        # depth below the feeder top (top = 1)
end

function _feeder_of(lay)
    N = length(lay.own)
    feeder = zeros(Int, N)
    stack = [(c, c) for c in lay.children[lay.root]]
    while !isempty(stack)
        j, f = pop!(stack)
        feeder[j] = f
        for c in lay.children[j]; push!(stack, (c, f)); end
    end
    return feeder
end

function tree_kkt_static(lay, K::SparseMatrixCSC)
    N = length(lay.own); nF = length(lay.Fc); nE = length(lay.E)
    feeder = _feeder_of(lay)
    owner_node = zeros(Int, nF)
    for j in 1:N, t in lay.own_Fc[j]; owner_node[t] = j; end
    Epos = Dict(i => t for (t, i) in enumerate(lay.E))
    Fcpos = Dict(i => t for (t, i) in enumerate(lay.Fc))
    rows = rowvals(K)
    E_group = zeros(Int, nE)
    kef = NTuple{3,Int}[]
    for (a, i) in enumerate(lay.E), p in nzrange(K, i)
        t = get(Fcpos, rows[p], 0); t == 0 && continue
        push!(kef, (a, t, p))
        f = feeder[owner_node[t]]; g = f == 0 ? -1 : f
        E_group[a] == 0 || E_group[a] == g || error("E index couples to two feeders")
        E_group[a] = g
    end
    for _ in 1:2, (a, i) in enumerate(lay.E), p in nzrange(K, i)   # follow K_EE
        b = get(Epos, rows[p], 0); b == 0 && continue
        if E_group[a] == 0 && E_group[b] != 0
            E_group[a] = E_group[b]
        elseif E_group[a] != 0 && E_group[b] != 0 && E_group[a] != E_group[b]
            error("K_EE couples two feeders (exact Hessian?): no block structure")
        end
    end
    all(!=(0), E_group) || error("E index with no feeder")
    gkeys = sort!(unique(E_group))
    gidx = Dict(g => t for (t, g) in enumerate(gkeys))
    members = [Int[] for _ in gkeys]
    for a in 1:nE; push!(members[gidx[E_group[a]]], a); end
    perm = vcat(members...)
    granges = UnitRange{Int}[]; off = 0
    loc = zeros(Int, nE)
    for m in members
        push!(granges, off+1:off+length(m)); off += length(m)
        for (t, a) in enumerate(m); loc[a] = t; end
    end
    kee = [NTuple{3,Int}[] for _ in gkeys]
    for (a, i) in enumerate(lay.E), p in nzrange(K, i)
        b = get(Epos, rows[p], 0); b == 0 && continue
        push!(kee[gidx[E_group[a]]], (loc[b], loc[a], p))            # K[E_b, E_a]
    end
    colpos = [Dict{Int,Int}() for _ in 1:N]
    for top in lay.children[lay.root], (s, t) in enumerate(lay.cols[top]); colpos[top][t] = s; end
    gkef = [NTuple{3,Int}[] for _ in gkeys]
    for (a, t, p) in kef
        g = E_group[a]; g == -1 && continue
        push!(gkef[gidx[g]], (loc[a], colpos[g][t], p))
    end
    iso_d = Int[]; iso_e = Vector{NTuple{2,Int}}[]
    giso = [NTuple{5,Int}[] for _ in gkeys]
    for (si, i) in enumerate(lay.iso)
        es = NTuple{2,Int}[]; dp = 0
        for p in nzrange(K, i)
            r = rows[p]
            r == i && (dp = p)
            haskey(Epos, r) && push!(es, (Epos[r], p))
        end
        dp == 0 && error("energy slack without a diagonal entry")
        push!(iso_d, dp); push!(iso_e, es)
        for (a, pa) in es, (b, pb) in es
            E_group[a] == E_group[b] || error("energy slack couples two groups")
            push!(giso[gidx[E_group[a]]], (loc[a], loc[b], pa, pb, si))
        end
    end
    ooff = zeros(Int, N); nN = 0
    for j in 1:N; ooff[j] = nN; nN += length(lay.own[j]); end
    need = [Int[] for _ in 1:N]
    for j in 1:N
        isempty(lay.cols[j]) && continue
        v = copy(lay.own_Fc_pos[j])
        for c in lay.children[j]; isempty(lay.cols[c]) || append!(v, lay.iface_pos[c]); end
        need[j] = sort!(unique(v))
    end
    iface_in_need = [Int[] for _ in 1:N]; fc_in_need = [Int[] for _ in 1:N]
    cidx = [Int[] for _ in 1:N]; depth = zeros(Int, N)
    for j in 1:N
        (isempty(lay.cols[j]) || j == lay.root) && continue
        f = feeder[j]
        cidx[j] = [colpos[f][t] for t in lay.cols[j]]
        fc_in_need[j] = [findfirst(==(pos), need[j]) for pos in lay.own_Fc_pos[j]]
        if j != f
            p = lay.parent[j]
            iface_in_need[j] = [findfirst(==(pos), need[p]) for pos in lay.iface_pos[j]]
        end
        d = 1; k = j
        while k != f; k = lay.parent[k]; d += 1; end
        depth[j] = d
    end
    return TreeKKTStatic(feeder, gkeys, perm, granges, kee, kef, gkef, iso_d, iso_e, giso,
                         colpos, ooff, nN, need, iface_in_need, fc_in_need, cidx, depth)
end

# The dense blocks here are small or mid-sized (a feeder's batteries), where
# OpenBLAS's threading costs more than it gains: a 498 x 498 LU takes 22 ms on
# ten threads and 3 ms on one. Run them on one BLAS thread.
const _BLAS_DEFAULT = Ref(BLAS.get_num_threads())
function _blas1(f)
    n = BLAS.get_num_threads()
    n == 1 && return f()
    _BLAS_DEFAULT[] = n
    BLAS.set_num_threads(1)
    try
        return f()
    finally
        BLAS.set_num_threads(n)
    end
end
# A large dense block inside a _blas1 region: restore the threads for it.
function _blas_full(f, n::Int)
    (n < 1000 || BLAS.get_num_threads() == _BLAS_DEFAULT[]) && return f()
    BLAS.set_num_threads(_BLAS_DEFAULT[])
    try
        return f()
    finally
        BLAS.set_num_threads(1)
    end
end

# FILTERDDP_HALF_BLOCK=1: factor the battery block at half size. E holds the
# battery powers and the energy rows; the energy rows couple to the powers
# and, once the energy slacks are eliminated, to themselves only, so their
# block is diagonal. Eliminating them leaves a block in the powers alone:
#     Shat = S_PP - S_PN inv(S_NN) S_NP,
# an eighth of the factorization work and a quarter of the multi-column solve,
# whatever the feeder topology. The same linear system in another elimination
# order: results agree to rounding. Falls back to the full block if a group's
# rows are not [powers; energy rows], its energy block is not diagonal, or the
# energy rows couple to the network.
_half_block() = get(ENV, "FILTERDDP_HALF_BLOCK", "0") != "0"

struct TreeKKTStructured
    perm::Vector{Int}
    granges::Vector{UnitRange{Int}}
    Dfac::Vector{LU{Float64, Matrix{Float64}, Vector{Int}}}
    Up::Matrix{Float64}             # U in the permuted (grouped) order, nE x m_root
    DUp::Matrix{Float64}            # D \ U, same order
    small::LU{Float64, Matrix{Float64}, Vector{Int}}   # M - U' (D \ U)
    M::Matrix{Float64}
    Dfull::Matrix{Float64}          # (verification only) dense D in E order
    # Exact battery curvature: D is no longer block diagonal, so the whole
    # Schur complement S = D + Vc - U inv(M) U' is factored densely instead.
    Sfac::Union{Nothing, LU{Float64, Matrix{Float64}, Vector{Int}}, Cholesky{Float64, Matrix{Float64}}}
    # FILTERDDP_HALF_BLOCK: each group's rows are [power rows; energy rows] and the
    # energy rows' block is diagonal, so they are eliminated and only the power
    # rows are factored (Dfac, or Sfac under the exact Hessian). Empty nP: not halved.
    nP::Vector{Int}                 # per group: number of power rows
    Ninv::Vector{Vector{Float64}}   # per group: inverse of the energy rows' diagonal
    PN::Vector{SparseMatrixCSC{Float64, Int}}   # per group: power x energy block (one entry per battery)
    NP::Vector{SparseMatrixCSC{Float64, Int}}   # per group: energy x power block
    prow::Vector{Int}               # grouped positions of all power rows (exact Hessian)
end

tree_kkt_structured(lay, stat::TreeKKTStatic, fac::TreeKKTFactor, K::SparseMatrixCSC;
                    dense_check::Bool=false, Vc=nothing) =
    _blas1(() -> _tree_kkt_structured(lay, stat, fac, K, dense_check, Vc))

function _tree_kkt_structured(lay, stat::TreeKKTStatic, fac::TreeKKTFactor, K::SparseMatrixCSC, dense_check::Bool, Vc)
    Bd, Up = _tree_kkt_prepare(lay, stat, fac, K)
    return _tree_kkt_finish(lay, stat, fac, K, Bd, Up, dense_check, Vc)
end

# The structured form in two steps, split by what they read.
#
# _tree_kkt_prepare reads the network factor and K_E,Fc only: the feeder
# inverse blocks Bd and U = K_E,Fc * Psi. Like tree_kkt_factor it never reads
# K_EE, which is the only place the next stage's value function enters a stage
# matrix (the battery-power diagonal under the diagonal Hessian, Vc under the
# exact one). So factor + prepare of every stage can be done before the
# backward sweep, all stages at once (checked by tree_kkt_phase_check.jl,
# which overwrites K_EE with NaN and compares).
#
# _tree_kkt_finish reads K_EE and Vc: the feeder blocks of the Schur
# complement and their factorization. This is what the sweep does in sequence.
function _tree_kkt_prepare(lay, stat::TreeKKTStatic, fac::TreeKKTFactor, K::SparseMatrixCSC)
    N = length(lay.own); nF = length(lay.Fc); nE = length(lay.E)
    root = lay.root; mr = length(lay.own[root])
    nz = nonzeros(K)

    # Upward sweep of the unit Fc columns, stopping below the root.
    Z = Vector{Matrix{Float64}}(undef, N)
    msg = Vector{Matrix{Float64}}(undef, N)
    @inbounds for j in lay.post
        j == root && continue
        k = length(lay.cols[j]); k == 0 && continue
        m = length(lay.own[j])
        R = zeros(m, k)
        for (t, pos) in enumerate(lay.own_Fc_pos[j]); R[pos, t] = 1.0; end
        off = length(lay.own_Fc[j])
        for c in lay.children[j]
            kc = length(lay.cols[c]); kc == 0 && continue
            pos = lay.iface_pos[c]; mc = msg[c]
            for cc in 1:kc, t in eachindex(pos); R[pos[t], off+cc] += mc[t, cc]; end
            off += kc
        end
        Zj = fac.F[j] \ R
        Z[j] = Zj
        mj = smallmul(fac.Aio[j], Zj); mj .*= -1
        msg[j] = mj
    end

    # Downward sweeps per feeder: Bd with zero root values, Psi from unit root
    # values. Each feeder works on its own k_f + q columns.
    Bd = Vector{Matrix{Float64}}(undef, N)
    Psi = zeros(nF, mr)
    @inbounds for top in lay.children[root]
        kf = length(lay.cols[top]); kf == 0 && continue
        colpos = stat.colpos[top]
        Bf = zeros(kf, kf)
        ipos = lay.iface_pos[top]; q = length(ipos)
        # One buffer per depth holds the needed rows of the node being
        # processed at that depth; a node's rows stay valid while its subtree
        # is processed, since only deeper buffers are written meanwhile.
        w = kf + q
        bufs = Matrix{Float64}[]
        ensure(d, nr) = (while length(bufs) < d; push!(bufs, zeros(max(nr, 4), w)); end;
                         size(bufs[d], 1) < nr && (bufs[d] = zeros(nr, w)); bufs[d])
        nd = stat.need[top]; y = ensure(1, length(nd))
        Ztop = Z[top]; Wtop = fac.W[top]
        for (r, pos) in enumerate(nd)
            for cc in 1:kf; y[r, cc] = Ztop[pos, cc]; end
            for cc in 1:q; y[r, kf+cc] = -Wtop[pos, cc]; end
        end
        stack = [top]
        while !isempty(stack)
            j = pop!(stack); d = stat.depth[j]
            if j != top
                # Rows of this node from its parent's (depth d-1), computed
                # now, when the node is processed, so siblings cannot clash.
                yp = bufs[d-1]; ndj = stat.need[j]; yj = ensure(d, length(ndj))
                Wj = fac.W[j]; iin = stat.iface_in_need[j]; Zj = Z[j]; ci = stat.cidx[j]
                for (r, pos) in enumerate(ndj)
                    for cc in 1:w
                        v = 0.0
                        for qq in eachindex(iin); v -= Wj[pos, qq] * yp[iin[qq], cc]; end
                        yj[r, cc] = v
                    end
                    for s in eachindex(ci); yj[r, ci[s]] += Zj[pos, s]; end
                end
            end
            yj = bufs[d]
            for (t, r) in zip(lay.own_Fc[j], stat.fc_in_need[j])
                row = colpos[t]
                for cc in 1:kf; Bf[row, cc] = yj[r, cc]; end
                for cc in 1:q; Psi[t, ipos[cc]] = -yj[r, kf+cc]; end
            end
            for c in lay.children[j]
                isempty(lay.cols[c]) || push!(stack, c)
            end
        end
        Bd[top] = Bf
    end
    @inbounds for (t, pos) in zip(lay.own_Fc[root], lay.own_Fc_pos[root])
        Psi[t, pos] = -1.0
    end

    # U = K_E,Fc * Psi (permuted order).
    invp = invperm(stat.perm)
    Up = zeros(nE, mr)
    @inbounds for (a, t, p) in stat.kef
        v = nz[p]; r = invp[a]
        for c in 1:mr; Up[r, c] += v * Psi[t, c]; end
    end
    return Bd, Up
end

function _tree_kkt_finish(lay, stat::TreeKKTStatic, fac::TreeKKTFactor, K::SparseMatrixCSC, Bd, Up,
                          dense_check::Bool, Vc)
    nE = length(lay.E); mr = length(lay.own[lay.root])
    nz = nonzeros(K)
    invp = invperm(stat.perm)
    # The diagonal blocks D_g.
    ng = length(stat.gkeys)
    Dfac = Vector{LU{Float64, Matrix{Float64}, Vector{Int}}}(undef, ng)
    DUp = similar(Up)
    Dfull = dense_check ? zeros(nE, nE) : zeros(0, 0)
    exact = !isnothing(Vc)
    Sdense = exact ? zeros(nE, nE) : zeros(0, 0)      # permuted (grouped) order
    Dgs = Vector{Matrix{Float64}}(undef, ng)
    @inbounds for gi in 1:ng
        rg = stat.granges[gi]; n = length(rg)
        Dg = zeros(n, n)
        for (b, a, p) in stat.kee[gi]; Dg[b, a] = nz[p]; end
        if stat.gkeys[gi] != -1
            Bf = Bd[stat.gkeys[gi]]
            ge = stat.gkef[gi]
            for (a, fa, pa) in ge, (b, fb, pb) in ge
                Dg[a, b] -= nz[pa] * Bf[fa, fb] * nz[pb]
            end
        end
        for (a, b, pa, pb, si) in stat.giso[gi]
            Dg[a, b] -= nz[pa] * nz[pb] / nz[stat.iso_d[si]]
        end
        dense_check && (Dfull[stat.perm[rg], stat.perm[rg]] .= Dg)
        Dgs[gi] = Dg
    end
    # Can the energy rows be eliminated? Power rows are the E rows coupled to the network.
    half = _half_block()
    nPv = Int[]; Ninv = Vector{Float64}[]; prow = Int[]
    PN = SparseMatrixCSC{Float64, Int}[]; NP = SparseMatrixCSC{Float64, Int}[]
    if half
        isP = falses(nE)
        for (a, t, p) in stat.kef; isP[a] = true; end
        nPv = zeros(Int, ng)
        for gi in 1:ng
            rg = stat.granges[gi]; n = length(rg); Dg = Dgs[gi]
            np = count(l -> isP[stat.perm[rg[l]]], 1:n)
            ok = all(l -> isP[stat.perm[rg[l]]] == (l <= np), 1:n)
            for l2 in np+1:n, l1 in np+1:n
                ok &= l1 == l2 ? Dg[l1, l1] != 0 : Dg[l1, l2] == 0
            end
            ok &= all(iszero, @view Up[rg[np+1:n], :])
            if !ok
                half = false; nPv = Int[]
                break
            end
            nPv[gi] = np
        end
    end
    if half
        for gi in 1:ng
            rg = stat.granges[gi]; n = length(rg); np = nPv[gi]; Dg = Dgs[gi]
            push!(Ninv, [1 / Dg[l, l] for l in np+1:n])
            push!(PN, sparse(Dg[1:np, np+1:n])); push!(NP, sparse(Dg[np+1:n, 1:np]))
            append!(prow, rg[1:np])
        end
        # the halved value update uses S_NP = S_PN'
        if !all(gi -> PN[gi] == sparse(NP[gi]'), 1:ng)
            half = false; nPv = Int[]; empty!(Ninv); empty!(PN); empty!(NP); empty!(prow)
        end
    end
    if exact
        nB = size(Vc, 1)
        (size(Vc) == (nB, nB) && nB <= nE) || error("battery curvature has the wrong size")
        @inbounds for gi in 1:ng
            rg = stat.granges[gi]
            Sdense[rg, rg] .= Dgs[gi]
        end
        @inbounds for b in 1:nB, a in 1:nB
            Sdense[invp[a], invp[b]] += Vc[a, b]      # battery powers are the first n_B of E
        end
        Sdense .-= Up * (fac.Mroot \ Up')
        if half
            Sh = Sdense[prow, prow]
            off = 0
            @inbounds for gi in 1:ng
                np = nPv[gi]
                Sh[off+1:off+np, off+1:off+np] .-= Matrix(PN[gi] * (Diagonal(Ninv[gi]) * NP[gi]))
                off += np
            end
            Sfac = _blas_full(() -> lu!(Sh), length(prow))
        else
            Sfac = _blas_full(() -> lu!(Sdense), nE)
        end
        return TreeKKTStructured(stat.perm, stat.granges, Dfac, Up, DUp, lu(fac.Mroot), fac.Mroot, Dfull, Sfac,
                                 nPv, Ninv, PN, NP, prow)
    end
    @inbounds for gi in 1:ng
        rg = stat.granges[gi]; Dg = Dgs[gi]
        if half
            np = nPv[gi]; rP = rg[1:np]
            Sh = Dg[1:np, 1:np]
            Sh .-= Matrix(PN[gi] * (Diagonal(Ninv[gi]) * NP[gi]))
            F = lu!(Sh)
            Dfac[gi] = F
            DUp[rP, :] = F \ Up[rP, :]
            DUp[rg[np+1:end], :] .= 0.0
        else
            F = lu!(Dg)
            Dfac[gi] = F
            DUp[rg, :] = F \ Up[rg, :]
        end
    end
    small = lu!(fac.Mroot - Up' * DUp)
    return TreeKKTStructured(stat.perm, stat.granges, Dfac, Up, DUp, small, fac.Mroot, Dfull, nothing,
                             nPv, Ninv, PN, NP, prow)
end

# FILTERDDP_LEAN_EXACT=1 (exact battery-block Hessian, with FILTERDDP_HALF_BLOCK=1).
# Without it the exact path builds the battery block at 2 n_B with the curvature
# inside, reduces it and factors it, all in the sweep (_tree_kkt_finish). But
# the curvature only adds to the power rows, so the halved block is
#     Shat = Shat0 + Vc,   Shat0 = blockdiag_g(D_PP - D_PN inv(D_NN) D_NP) - U_P inv(M) U_P',
# and Shat0 reads nothing from the next stage. _tree_kkt_finish0 builds it
# before the sweep, at its final size n_B; the sweep (_tree_kkt_finishV) adds
# Vc and factors, by Cholesky (LU if that fails). Same linear system: results
# agree with the plain exact path to rounding.
_lean_exact() = get(ENV, "FILTERDDP_LEAN_EXACT", "0") != "0"

struct TreeKKTBlock0
    Sh0::Matrix{Float64}            # row/column k = grouped row prow[k]
    bat::Vector{Int}                # battery (index in E) of each of those rows
    nP::Vector{Int}
    Ninv::Vector{Vector{Float64}}
    PN::Vector{SparseMatrixCSC{Float64, Int}}
    NP::Vector{SparseMatrixCSC{Float64, Int}}
    prow::Vector{Int}
    Up::Matrix{Float64}
end

# Returns nothing if the block cannot be halved (same conditions as in
# _tree_kkt_finish, whose group assembly and checks are repeated here).
function _tree_kkt_finish0(lay, stat::TreeKKTStatic, fac::TreeKKTFactor, K::SparseMatrixCSC, Bd, Up, nB::Int)
    nE = length(lay.E); nz = nonzeros(K)
    ng = length(stat.gkeys)
    Dgs = Vector{Matrix{Float64}}(undef, ng)
    @inbounds for gi in 1:ng
        rg = stat.granges[gi]; n = length(rg)
        Dg = zeros(n, n)
        for (b, a, p) in stat.kee[gi]; Dg[b, a] = nz[p]; end
        if stat.gkeys[gi] != -1
            Bf = Bd[stat.gkeys[gi]]
            ge = stat.gkef[gi]
            for (a, fa, pa) in ge, (b, fb, pb) in ge
                Dg[a, b] -= nz[pa] * Bf[fa, fb] * nz[pb]
            end
        end
        for (a, b, pa, pb, si) in stat.giso[gi]
            Dg[a, b] -= nz[pa] * nz[pb] / nz[stat.iso_d[si]]
        end
        Dgs[gi] = Dg
    end
    isP = falses(nE)
    for (a, t, p) in stat.kef; isP[a] = true; end
    nPv = zeros(Int, ng)
    for gi in 1:ng
        rg = stat.granges[gi]; n = length(rg); Dg = Dgs[gi]
        np = count(l -> isP[stat.perm[rg[l]]], 1:n)
        ok = all(l -> isP[stat.perm[rg[l]]] == (l <= np), 1:n)
        for l2 in np+1:n, l1 in np+1:n
            ok &= l1 == l2 ? Dg[l1, l1] != 0 : Dg[l1, l2] == 0
        end
        ok &= all(iszero, @view Up[rg[np+1:n], :])
        ok || return nothing
        nPv[gi] = np
    end
    Ninv = Vector{Float64}[]; prow = Int[]
    PN = SparseMatrixCSC{Float64, Int}[]; NP = SparseMatrixCSC{Float64, Int}[]
    for gi in 1:ng
        rg = stat.granges[gi]; n = length(rg); np = nPv[gi]; Dg = Dgs[gi]
        push!(Ninv, [1 / Dg[l, l] for l in np+1:n])
        push!(PN, sparse(Dg[1:np, np+1:n])); push!(NP, sparse(Dg[np+1:n, 1:np]))
        append!(prow, rg[1:np])
    end
    all(gi -> PN[gi] == sparse(NP[gi]'), 1:ng) || return nothing
    n = length(prow)
    bat = [stat.perm[prow[k]] for k in 1:n]
    (n == nB && all(<=(nB), bat)) || return nothing
    Sh0 = zeros(n, n)
    off = 0
    @inbounds for gi in 1:ng
        np = nPv[gi]
        blk = Dgs[gi][1:np, 1:np]
        blk .-= Matrix(PN[gi] * (Diagonal(Ninv[gi]) * NP[gi]))
        Sh0[off+1:off+np, off+1:off+np] .= blk
        off += np
    end
    UpP = Up[prow, :]
    Sh0 .-= UpP * (fac.Mroot \ UpP')
    return TreeKKTBlock0(Sh0, bat, nPv, Ninv, PN, NP, prow, Up)
end

function _tree_kkt_finishV(stat::TreeKKTStatic, fac::Union{TreeKKTFactor,SparseNetworkKKTFactor}, b0::TreeKKTBlock0, Vc::AbstractMatrix)
    bat = b0.bat; n = length(bat)
    shat() = begin
        Sh = Matrix{Float64}(undef, n, n)
        @inbounds for l in 1:n, k in 1:n; Sh[k, l] = b0.Sh0[k, l] + Vc[bat[k], bat[l]]; end
        Sh
    end
    C = _blas_full(() -> cholesky!(Symmetric(shat()); check=false), n)
    Sfac = issuccess(C) ? C : _blas_full(() -> lu!(shat()), n)
    return TreeKKTStructured(stat.perm, stat.granges, LU{Float64, Matrix{Float64}, Vector{Int}}[], b0.Up,
                             similar(b0.Up), lu(fac.Mroot), fac.Mroot, zeros(0, 0), Sfac,
                             b0.nP, b0.Ninv, b0.PN, b0.NP, b0.prow)
end

# S \ R for S = D - U inv(M) U' (Woodbury): X = D\R + D\U * ((M - U' D\U) \ (U' D\R)).
# Works in the grouped order so that each group is a contiguous row block.
function tree_kkt_schur_solve(st::TreeKKTStructured, R::AbstractMatrix)
    Rp = R[st.perm, :]
    tree_kkt_schur_solve_grouped!(st, Rp)
    X = Matrix{Float64}(undef, size(Rp))
    X[st.perm, :] = Rp
    return X
end

# The same solve in place, on a right-hand side already in the grouped order.
# The feeder blocks are independent: with several columns they are solved on
# the Julia threads (each on one BLAS thread), with identical results.
function tree_kkt_schur_solve_grouped!(st::TreeKKTStructured, Rp::AbstractMatrix)
    ng = length(st.granges)
    halved = !isempty(st.nP)
    threaded = Threads.nthreads() > 1 && ng > 1 && size(Rp, 2) > 1
    # Halved block: r_P -= S_PN inv(S_NN) r_N, leaving inv(S_NN) r_N in the energy rows
    fold!(g) = begin
        rg = st.granges[g]; np = st.nP[g]
        rN = view(Rp, rg[np+1:end], :)
        lmul!(Diagonal(st.Ninv[g]), rN)
        mul!(view(Rp, rg[1:np], :), st.PN[g], rN, -1.0, 1.0)
    end
    # ... and x_N = inv(S_NN) (r_N - S_NP x_P)
    unfold!(g) = begin
        rg = st.granges[g]; np = st.nP[g]
        tmp = st.NP[g] * view(Rp, rg[1:np], :)
        lmul!(Diagonal(st.Ninv[g]), tmp)
        view(Rp, rg[np+1:end], :) .-= tmp
    end
    if !isnothing(st.Sfac)
        if halved
            _blas1() do
                for g in 1:ng; fold!(g); end
            end
            Xc = Rp[st.prow, :]
            ldiv!(st.Sfac, Xc)
            Rp[st.prow, :] = Xc
            _blas1() do
                for g in 1:ng; unfold!(g); end
            end
        else
            ldiv!(st.Sfac, Rp)
        end
        return Rp
    end
    block!(g) = begin
        rg = st.granges[g]
        if halved
            fold!(g)
            ldiv!(st.Dfac[g], view(Rp, rg[1:st.nP[g]], :))
        else
            ldiv!(st.Dfac[g], view(Rp, rg, :))
        end
    end
    _blas1() do
        if threaded
            Threads.@threads for g in 1:ng; block!(g); end
        else
            for g in 1:ng; block!(g); end
        end
    end
    T = st.small \ (st.Up' * Rp)
    mul!(Rp, st.DUp, T, 1.0, 1.0)
    if halved
        _blas1() do
            if threaded
                Threads.@threads for g in 1:ng; unfold!(g); end
            else
                for g in 1:ng; unfold!(g); end
            end
        end
    end
    return Rp
end

function tree_kkt_schur_dense(st::TreeKKTStructured)
    invp = invperm(st.perm)
    U = st.Up[invp, :]
    return st.Dfull - U * (st.M \ U')
end

# ------------------------------------------------------------- full solver --
# One object per stage that replaces the stage's sparse LU: full solves
# K \ b (feedforward column, forward-pass policy) and the battery rows of the
# feedback columns. With N the network part and E last,
#     y   = N \ b_F
#     x_E = S \ (b_E - K_EF y - K_E,iso (b_iso ./ d_iso))
#     x_F = y - N \ (K_FE x_E),   x_iso = (b_iso - K_iso,E x_E) ./ d_iso.

struct TreeKKTSolver{F}
    lay::TreeKKTLayout
    stat::TreeKKTStatic
    fac::F
    st::TreeKKTStructured
    nz::Vector{Float64}                    # copy of the K values the couplings are read from
    pre::Vector{Int}                       # nodes, parents before children
    z::Vector{Float64}                     # flat work buffer for the network solves
    y1::Vector{Float64}
    y2::Vector{Float64}
    t2::Vector{Float64}
    # Seconds spent, by what the work needs from the next stage (see
    # _tree_kkt_prepare): [1] factor + prepare (nothing), [2] finish (the value
    # function), and accumulated over the solves [3] first network solve
    # (nothing), [4] battery block solve, [5] second network solve (this
    # stage's battery solution only).
    times::Vector{Float64}
end

function tree_kkt_solver(lay::TreeKKTLayout, stat::TreeKKTStatic, K::SparseMatrixCSC; Vc=nothing)
    t0 = time_ns()
    fac = network_kkt_factor(lay, K)
    Bd, Up = _blas1(() -> _tree_kkt_prepare(lay, stat, fac, K))
    nzc = copy(nonzeros(K)); pre = reverse(lay.post)
    z = zeros(stat.nN); y1 = zeros(lay.n); y2 = zeros(lay.n); t2 = zeros(lay.n)
    b0 = (!isnothing(Vc) && _lean_exact() && _half_block()) ?
        _blas1(() -> _tree_kkt_finish0(lay, stat, fac, K, Bd, Up, size(Vc, 1))) : nothing
    t1 = time_ns()
    st = isnothing(b0) ? _blas1(() -> _tree_kkt_finish(lay, stat, fac, K, Bd, Up, false, Vc)) :
        _blas1(() -> _tree_kkt_finishV(stat, fac, b0, Vc))
    times = [(t1 - t0) / 1e9, (time_ns() - t1) / 1e9, 0.0, 0.0, 0.0]
    return TreeKKTSolver(lay, stat, fac, st, nzc, pre, z, y1, y2, t2, times)
end
tree_kkt_solver(lay::TreeKKTLayout, K::SparseMatrixCSC) = tree_kkt_solver(lay, tree_kkt_static(lay, K), K)

# x[network rows] = N \ b[network rows], with no allocation: z holds every
# node's own block back to back, and must be zero on entry (it is on exit).
function tree_kkt_network_solve!(x::AbstractVector, s::TreeKKTSolver, b::AbstractVector)
    lay, fac, z, ooff = s.lay, s.fac, s.z, s.stat.ooff
    fac isa SparseNetworkKKTFactor && return sparse_network_solve!(x, fac, b)
    @inbounds for j in lay.post
        own = lay.own[j]; m = length(own); o = ooff[j]
        F = fac.F[j]; A = F.A; perm = F.perm
        # right-hand side = b + the children's messages (accumulated in z), pivoted
        for t in 1:m; x[own[t]] = b[own[t]] + z[o+t]; end
        for t in 1:m; z[o+t] = x[own[perm[t]]]; end
        for i in 2:m
            v = z[o+i]
            for k in 1:i-1; v -= A[i, k] * z[o+k]; end
            z[o+i] = v
        end
        for i in m:-1:1
            v = z[o+i]
            for k in i+1:m; v -= A[i, k] * z[o+k]; end
            z[o+i] = v / A[i, i]
        end
        if j != lay.root
            po = ooff[lay.parent[j]]; pos = lay.iface_pos[j]; Bio = fac.Aio[j]
            for q in eachindex(pos)
                v = 0.0
                for t in 1:m; v += Bio[q, t] * z[o+t]; end
                z[po+pos[q]] -= v                                # message to the parent
            end
        end
    end
    @inbounds for j in s.pre
        own = lay.own[j]; m = length(own); o = ooff[j]
        if j != lay.root
            po = ooff[lay.parent[j]]; pos = lay.iface_pos[j]; W = fac.W[j]
            for q in eachindex(pos)
                yI = z[po+pos[q]]
                yI == 0 && continue
                for t in 1:m; z[o+t] -= W[t, q] * yI; end
            end
        end
        for t in 1:m; x[own[t]] = z[o+t]; end
    end
    fill!(z, 0.0)
    return x
end

function tree_kkt_solve!(s::TreeKKTSolver, b::AbstractVector)
    lay, stat, nz = s.lay, s.stat, s.nz
    y, y2, t2 = s.y1, s.y2, s.t2
    t_a = time_ns()
    tree_kkt_network_solve!(y, s, b)
    t_b = time_ns()
    nE = length(lay.E)
    rE = Matrix{Float64}(undef, nE, 1)
    @inbounds for a in 1:nE; rE[a, 1] = b[lay.E[a]]; end
    @inbounds for (a, t, p) in stat.kef; rE[a, 1] -= nz[p] * y[lay.Fc[t]]; end
    @inbounds for (si, i) in enumerate(lay.iso)
        w = b[i] / nz[stat.iso_d[si]]
        for (a, p) in stat.iso_e[si]; rE[a, 1] -= nz[p] * w; end
    end
    xE = tree_kkt_schur_solve(s.st, rE)
    t_c = time_ns()
    fill!(t2, 0.0)
    @inbounds for (a, f, p) in stat.kef; t2[lay.Fc[f]] += nz[p] * xE[a, 1]; end
    tree_kkt_network_solve!(y2, s, t2)
    @inbounds for (si, i) in enumerate(lay.iso)
        v = b[i]
        for (a, p) in stat.iso_e[si]; v -= nz[p] * xE[a, 1]; end
        b[i] = v / nz[stat.iso_d[si]]
    end
    @inbounds for j in eachindex(lay.own), i in lay.own[j]; b[i] = y[i] - y2[i]; end
    @inbounds for a in 1:nE; b[lay.E[a]] = xE[a, 1]; end
    tm = s.times
    tm[3] += (t_b - t_a) / 1e9; tm[4] += (t_c - t_b) / 1e9; tm[5] += (time_ns() - t_c) / 1e9
    return b
end

function LinearAlgebra.ldiv!(s::TreeKKTSolver, B::AbstractVecOrMat)
    if B isa AbstractVector
        tree_kkt_solve!(s, B)
    else
        for c in axes(B, 2); tree_kkt_solve!(s, @view B[:, c]); end
    end
    return B
end

# Battery rows (in lay.E order) of K \ R for right-hand sides supported on E.
tree_kkt_battery_rows(s::TreeKKTSolver, RE::AbstractMatrix) = tree_kkt_schur_solve(s.st, RE)

# Battery rows of K \ R for R = -[B; cxE], B dense on the battery-power rows
# and cxE sparse on the energy rows (the feedback right-hand side), in the
# grouped order: row invp[i] of the result is row i of E. The right-hand side
# is written in that order directly and solved in place.
const _ROWS_WORK = Ref(zeros(0, 0))
function tree_kkt_battery_rows_grouped(s::TreeKKTSolver, B::AbstractMatrix, cxE::SparseMatrixCSC)
    st = s.st; nB, nx = size(B); nE = length(st.perm)
    (size(cxE) == (nE - nB, nx)) || return nothing
    invp = invperm(st.perm)
    # The result is used by the caller before the next stage is solved, so one
    # workspace serves every stage: no 2 n_B x n_x allocation per stage.
    size(_ROWS_WORK[]) == (nE, nx) || (_ROWS_WORK[] = Matrix{Float64}(undef, nE, nx))
    Rp = _ROWS_WORK[]
    @inbounds for j in 1:nx
        for k in 1:nB; Rp[invp[k], j] = -B[k, j]; end
        for k in nB+1:nE; Rp[invp[k], j] = 0.0; end
    end
    rv = rowvals(cxE); nzv = nonzeros(cxE)
    @inbounds for j in 1:nx, q in nzrange(cxE, j)
        Rp[invp[nB + rv[q]], j] = -nzv[q]
    end
    tree_kkt_schur_solve_grouped!(st, Rp)
    return Rp, invp
end


# Driver hook for FILTERDDP_TREE_KKT=1. The layout depends only on the network
# and on K's sparsity pattern, so it is built once and rebuilt only if the
# pattern changes.
function install_tree_kkt_hook(data, idx, nu::Int)
    state = Ref{Any}(nothing)
    DDP4OPF.TREE_KKT_HOOK[] = function (K, Vc=nothing)
        st = state[]
        if isnothing(st) || st.colptr != K.colptr || st.rowval != K.rowval
            lay = tree_kkt_layout(data, idx, nu, K)
            st = (lay=lay, stat=tree_kkt_static(lay, K), colptr=copy(K.colptr), rowval=copy(K.rowval))
            state[] = st
            println("TREE_KKT layout: nodes=", length(lay.own), " feeders=",
                    length(lay.children[lay.root]), " nE=", length(lay.E),
                    " groups=", length(st.stat.gkeys),
                    " max_own=", maximum(length, lay.own), " max_iface=", maximum(length, lay.iface))
        end
        return tree_kkt_solver(st.lay, st.stat, K; Vc=Vc)
    end
    return nothing
end

function DDP4OPF.battery_block_rows(F::TreeKKTSolver, K, E, R)
    E == F.lay.E || error("battery rows differ from the tree layout's")
    return tree_kkt_battery_rows(F, R)
end

# The value update on the halved block (FILTERDDP_HALF_BLOCK), on the power rows
# only. With R = -[B; cxE] and X = S \ R, eliminating the energy rows gives
#     Rhat = -B + S_PN inv(S_NN) cxE,     X_P = Shat \ Rhat,
#     X' [B; cxE] = -X_P' Rhat - cxE' inv(S_NN) cxE      (S_NP = S_PN'),
# so the energy rows of X are never formed: one n_B x n_x right-hand side, one
# solve on it and one product, instead of 2 n_B rows, two gathers and a second
# term. Returns the battery rows of the feedback (in E order) and the value
# increment, or nothing if the block is not halved or cxE has a row with more
# than one entry.
const _HALF_WORK = Ref((zeros(0, 0), zeros(0, 0)))
function tree_kkt_value_halved(s::TreeKKTSolver, B::AbstractMatrix, cxE::SparseMatrixCSC)
    st = s.st
    isempty(st.nP) && return nothing
    exact = !isnothing(st.Sfac)
    exact && !_lean_exact() && return nothing
    nB, nx = size(B); nE = length(st.perm); ng = length(st.granges)
    (length(st.prow) == nB && size(cxE) == (nE - nB, nx)) || return nothing
    ecol = zeros(Int, nE - nB); ecx = zeros(nE - nB)            # the one entry of each energy row
    rv = rowvals(cxE); nzv = nonzeros(cxE)
    for j in 1:nx, q in nzrange(cxE, j)
        ecol[rv[q]] == 0 || return nothing
        ecol[rv[q]] = j; ecx[rv[q]] = nzv[q]
    end
    size(_HALF_WORK[][1]) == (nB, nx) || (_HALF_WORK[] = (Matrix{Float64}(undef, nB, nx), Matrix{Float64}(undef, nB, nx)))
    Rhat, Xc = _HALF_WORK[]
    bat = Vector{Int}(undef, nB)                                 # battery row of each compact row
    for k in 1:nB
        b = st.perm[st.prow[k]]; b <= nB || return nothing
        bat[k] = b
    end
    @inbounds for j in 1:nx, k in 1:nB
        Rhat[k, j] = -B[bat[k], j]
    end
    Vinc = Matrix{Float64}(undef, nx, nx)
    dterm = zeros(nx)                                            # diagonal of cxE' inv(S_NN) cxE
    off = 0
    for g in 1:ng
        rg = st.granges[g]; np = st.nP[g]; PNg = st.PN[g]; ninv = st.Ninv[g]
        prv = rowvals(PNg); pnz = nonzeros(PNg)
        for l in 1:length(rg) - np
            er = st.perm[rg[np + l]] - nB; j = ecol[er]; j == 0 && continue
            c = ecx[er]
            dterm[j] += c * ninv[l] * c
            for q in nzrange(PNg, l)
                Rhat[off + prv[q], j] += pnz[q] * ninv[l] * c
            end
        end
        off += np
    end
    if exact
        # FILTERDDP_LEAN_EXACT: the block is one dense n_B x n_B factor. With a
        # Cholesky factor U'U the increment needs only Y = U' \ Rhat:
        #     -Rhat' inv(Shat) Rhat = -Y'Y.
        # The battery rows of the feedback, inv(U) Y, are not needed by the
        # sweep; they are formed for the one-worker-per-period accounting only
        # and timed with the stage's own back-substitution (times[5]).
        F = st.Sfac
        copyto!(Xc, Rhat)
        XB = zeros(0, 0)
        if F isa Cholesky
            _blas1(() -> _blas_full(nB) do
                ldiv!(F.U', Xc)
                BLAS.syrk!('U', 'T', -1.0, Xc, 0.0, Vinc)
            end)
            LinearAlgebra.copytri!(Vinc, 'U')
            if DDP4OPF._parsim()
                t0 = time_ns()
                _blas1(() -> _blas_full(() -> ldiv!(F.U, Xc), nB))
                XB = Matrix{Float64}(undef, nB, nx)
                @inbounds for j in 1:nx, k in 1:nB; XB[bat[k], j] = Xc[k, j]; end
                s.times[5] += (time_ns() - t0) / 1e9
            end
        else
            _blas1(() -> _blas_full(nB) do
                ldiv!(F, Xc)
                mul!(Vinc, Xc', Rhat, -1.0, 0.0)
            end)
            XB = Matrix{Float64}(undef, nB, nx)
            @inbounds for j in 1:nx, k in 1:nB; XB[bat[k], j] = Xc[k, j]; end
        end
        @inbounds for j in 1:nx; Vinc[j, j] -= dterm[j]; end
        return XB, Vinc
    end
    copyto!(Xc, Rhat)
    offs = cumsum(vcat(0, st.nP))
    _blas1() do
        if Threads.nthreads() > 1 && ng > 1
            Threads.@threads for g in 1:ng
                ldiv!(st.Dfac[g], view(Xc, offs[g]+1:offs[g+1], :))
            end
        else
            for g in 1:ng; ldiv!(st.Dfac[g], view(Xc, offs[g]+1:offs[g+1], :)); end
        end
    end
    UpP = st.Up[st.prow, :]
    T = st.small \ (UpP' * Xc)
    mul!(Xc, st.DUp[st.prow, :], T, 1.0, 1.0)
    mul!(Vinc, Xc', Rhat, -1.0, 0.0)
    @inbounds for j in 1:nx; Vinc[j, j] -= dterm[j]; end
    XB = Matrix{Float64}(undef, nB, nx)
    @inbounds for j in 1:nx, k in 1:nB
        XB[bat[k], j] = Xc[k, j]
    end
    return XB, Vinc
end
# Battery rows (in E order) of the feedback from the halved exact block alone:
# Shat \ Rhat with the right-hand side of tree_kkt_value_halved. The exact
# Hessian's sweep does not form these rows (the value update needs only
# U' \ Rhat); this is for a caller that wants them afterwards, e.g. for the
# state recursion of a forward pass run with the periods at once. It has its
# own work matrix, so several stages may call it at the same time. Returns an
# empty matrix if the block is not the halved exact one.
function tree_kkt_feedback_rows(s::TreeKKTSolver, B::AbstractMatrix, cxE::SparseMatrixCSC)
    st = s.st
    (isempty(st.nP) || isnothing(st.Sfac)) && return zeros(0, 0)
    nB, nx = size(B); nE = length(st.perm); ng = length(st.granges)
    (length(st.prow) == nB && size(cxE) == (nE - nB, nx)) || return zeros(0, 0)
    ecol = zeros(Int, nE - nB); ecx = zeros(nE - nB)
    rv = rowvals(cxE); nzv = nonzeros(cxE)
    for j in 1:nx, q in nzrange(cxE, j)
        ecol[rv[q]] == 0 || return zeros(0, 0)
        ecol[rv[q]] = j; ecx[rv[q]] = nzv[q]
    end
    bat = Vector{Int}(undef, nB)
    for k in 1:nB
        b = st.perm[st.prow[k]]; b <= nB || return zeros(0, 0)
        bat[k] = b
    end
    X = Matrix{Float64}(undef, nB, nx)
    @inbounds for j in 1:nx, k in 1:nB
        X[k, j] = -B[bat[k], j]
    end
    off = 0
    for g in 1:ng
        rg = st.granges[g]; np = st.nP[g]; PNg = st.PN[g]; ninv = st.Ninv[g]
        prv = rowvals(PNg); pnz = nonzeros(PNg)
        for l in 1:length(rg) - np
            er = st.perm[rg[np + l]] - nB; j = ecol[er]; j == 0 && continue
            c = ecx[er]
            for q in nzrange(PNg, l)
                X[off + prv[q], j] += pnz[q] * ninv[l] * c
            end
        end
        off += np
    end
    ldiv!(st.Sfac, X)
    XB = Matrix{Float64}(undef, nB, nx)
    @inbounds for j in 1:nx, k in 1:nB; XB[bat[k], j] = X[k, j]; end
    return XB
end
DDP4OPF.battery_value_halved(F::TreeKKTSolver, E, B, cxE) =
    E == F.lay.E ? tree_kkt_value_halved(F, B, cxE) : nothing

DDP4OPF.stage_phase_times(F::TreeKKTSolver) = F.times
DDP4OPF.reset_phase_times!(F::TreeKKTSolver) = (fill!(F.times, 0.0); nothing)
# Feeder group of each battery (its power row's block of the Schur complement)
function DDP4OPF.battery_groups(F::TreeKKTSolver, nB)
    st = F.st; g = zeros(Int, nB)
    for (gi, rg) in enumerate(st.granges), r in rg
        k = st.perm[r]
        k <= nB && (g[k] = gi)
    end
    return g
end
DDP4OPF.battery_block_rows_grouped(F::TreeKKTSolver, E, B, cxE) =
    E == F.lay.E ? tree_kkt_battery_rows_grouped(F, B, cxE) : nothing

# ------------------------------------------------------------- pint_scan.jl --
# Battery-level data of a stage that does not depend on the next stage's value
# function (diagnostic, FILTERDDP_PINT_SCAN; see pint_scan.jl). Neither function
# is on the solve path.

# r_E = b_E - K_EF (N \ b_F) - K_E,iso (b_iso ./ d_iso): the right-hand side of the
# battery block for a full right-hand side b, in lay.E order. Same operations as
# the first half of tree_kkt_solve!.
function tree_kkt_reduced_rhs(s::TreeKKTSolver, b::AbstractVector)
    lay, stat, nz = s.lay, s.stat, s.nz
    y = zeros(lay.n)
    tree_kkt_network_solve!(y, s, b)
    nE = length(lay.E)
    rE = Vector{Float64}(undef, nE)
    @inbounds for a in 1:nE; rE[a] = b[lay.E[a]]; end
    @inbounds for (a, t, p) in stat.kef; rE[a] -= nz[p] * y[lay.Fc[t]]; end
    @inbounds for (si, i) in enumerate(lay.iso)
        w = b[i] / nz[stat.iso_d[si]]
        for (a, p) in stat.iso_e[si]; rE[a] -= nz[p] * w; end
    end
    return rE
end

# The halved battery block without the battery curvature, in lay.E order:
#   S0   = S_PP - S_PN inv(S_NN) S_NP   (n_B x n_B, row/column k = battery k of E),
#   ninv = diagonal of inv(S_NN)        (entry e = energy row e of E),
#   SPN  = S_PN                         (battery x energy row, sparse).
# Recomputes prepare and finish with a zero curvature; needs FILTERDDP_HALF_BLOCK=1.
function tree_kkt_block0(s::TreeKKTSolver, K::SparseMatrixCSC, nB::Int)
    lay, stat, fac = s.lay, s.stat, s.fac
    Bd, Up = _blas1(() -> _tree_kkt_prepare(lay, stat, fac, K))
    st0 = _blas1(() -> _tree_kkt_finish(lay, stat, fac, K, Bd, Up, false, zeros(nB, nB)))
    (isempty(st0.nP) || isnothing(st0.Sfac)) && error("tree_kkt_block0 needs the halved block (FILTERDDP_HALF_BLOCK=1)")
    Fh = st0.Sfac
    Sh = (Fh.L * Fh.U)[invperm(Fh.p), :]
    length(st0.prow) == nB || error("the halved block has $(length(st0.prow)) power rows, expected $nB")
    bat = [st0.perm[st0.prow[k]] for k in 1:nB]
    all(<=(nB), bat) || error("a power row of the halved block is not a battery power")
    S0 = Matrix{Float64}(undef, nB, nB)
    @inbounds for l in 1:nB, k in 1:nB; S0[bat[k], bat[l]] = Sh[k, l]; end
    nN = length(st0.perm) - nB
    ninv = zeros(nN)
    I_ = Int[]; J_ = Int[]; V_ = Float64[]
    for (g, rg) in enumerate(st0.granges)
        npg = st0.nP[g]; PNg = st0.PN[g]; rv = rowvals(PNg); nzv = nonzeros(PNg)
        for l in 1:length(rg) - npg
            e = st0.perm[rg[npg + l]] - nB
            ninv[e] = st0.Ninv[g][l]
            for q in nzrange(PNg, l)
                push!(I_, st0.perm[rg[rv[q]]]); push!(J_, e); push!(V_, nzv[q])
            end
        end
    end
    return S0, ninv, sparse(I_, J_, V_, nB, nN)
end

include(joinpath(@__DIR__, "sparse_network_ablation.jl"))
