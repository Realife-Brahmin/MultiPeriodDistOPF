#!/usr/bin/env bash
# Local worker for the Kamiak day-148 sf6937 rated campaign, switch ratings raised to their conductor (335a30e3, 2026-11-03), on the 309 PC, with no network steps
# (the PC lost its connection mid-run; run_local*.sh held Kamiak tasks inline and, worse, let ssh read the queue
# file from stdin). Same commit (335a30e3), pinned environment (Kamiak's sdp_hsl Manifest) and settings as
# ~/msopf/jobs/farkas_day148_nov03/farkas_job.sh, Ipopt on HSL MA57. Per direction: phase A, then phase C once A has
# written its row. Directions are claimed with lock directories (locks/<d>). sync_kamiak.sh does the Kamiak side.
# Usage: local_worker.sh queue <file of directions, one per line>
#        local_worker.sh finish <dir>   (phase A already running from an earlier worker: wait for its row, then C)
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="C:/Users/Aryan Ritwajeet Jha/Documents/documents_general/MultiPeriodDistOPF/.claude/worktrees/opendss-voltage-bases-check-162c57"
JL="C:/Users/Aryan Ritwajeet Jha/.julia/juliaup/julia-1.12.7+0.x64.w64.mingw32/bin/julia.exe"
ENVP="C:/Users/Aryan Ritwajeet Jha/msopf_envs/sdp_hsl"
HSL="C:/Users/Aryan Ritwajeet Jha/Documents/hsl/build"
OUT="$HERE/sfp1u_four"; mkdir -p "$OUT/logs" "$HERE/locks"
export MULTIPERIOD_OUT_DIR="$OUT" MULTIPERIOD_SOLVE_LOG=0 FB_SYSTEM=sfp1u_four
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 JULIA_NUM_THREADS=1 MKL_NUM_THREADS=1
export FB_RATINGS=1 FB_LOADDAY=148
export IPOPT_EXTRA_OPTIONS="linear_solver=ma57;hsllib=$HSL/libma57.dll;ma57_pivot_order=2;ma57_pre_alloc=3.0;linear_system_scaling=none"
unset NO_COLOR FORCE_COLOR
say() { echo "$(date '+%H:%M:%S') $*"; }
rows() { wc -l < "$1" 2>/dev/null || echo 0; }

phase() {   # phase <A|C> <dir>
    local p=$1 d=$2 log="$OUT/logs/$1_$2"
    { echo "system=sfp1u_four phase=$p dir=$d host=$(hostname) start=$(date -Is)"; echo "ipopt_extra=$IPOPT_EXTRA_OPTIONS"
      echo "commit=$(git -C "$REPO" rev-parse HEAD)"; } > "$log.meta"
    (cd "$REPO" && FB_PHASE=$p FB_DIR=$d "$JL" --startup-file=no --project="$ENVP" problems/msopf/root_level/farkas_bracketing.jl > "$log.log" 2> "$log.err" < /dev/null)
    local rc=$?; echo "exit=$rc end=$(date -Is)" >> "$log.meta"; return $rc
}

do_c() {
    local d=$1 t0=$SECONDS
    if phase C $d && [ "$(rows "$OUT/fb_C_$d.csv")" -ge 2 ]; then
        say "dir $d: phase C done ($((SECONDS - t0)) s): $(tail -1 "$OUT/fb_C_$d.csv" | cut -d, -f5,7)"; touch "$HERE/locks/$d/done"
    else
        say "dir $d: phase C FAILED (see $OUT/logs)"; touch "$HERE/locks/$d/failed"
    fi
}

if [ "$1" = finish ]; then
    d=$2; t0=$SECONDS
    until [ "$(rows "$OUT/fb_A_$d.csv")" -ge 2 ] || [ $((SECONDS - t0)) -gt 5400 ]; do sleep 30; done
    [ "$(rows "$OUT/fb_A_$d.csv")" -ge 2 ] || { say "dir $d: no phase A row after 90 min"; touch "$HERE/locks/$d/failed"; exit 1; }
    say "dir $d: phase A done: $(tail -1 "$OUT/fb_A_$d.csv" | cut -d, -f3,5)"; do_c $d; exit 0
fi

for d in $(cat "$2"); do
    mkdir "$HERE/locks/$d" 2>/dev/null || continue
    say "dir $d: phase A"; t0=$SECONDS
    if phase A $d && [ "$(rows "$OUT/fb_A_$d.csv")" -ge 2 ]; then
        say "dir $d: phase A done ($((SECONDS - t0)) s): $(tail -1 "$OUT/fb_A_$d.csv" | cut -d, -f3,5)"; do_c $d
    else
        say "dir $d: phase A FAILED (see $OUT/logs)"; touch "$HERE/locks/$d/failed"
    fi
done
say "worker done"
