#!/usr/bin/env bash
# Kamiak side of the local day-148 sf6937 runs (local_worker.sh), one pass; run it in a loop. When Kamiak is reachable:
#  - a direction claimed locally and not finished: hold Kamiak's A and C tasks for it while they are still pending;
#  - a direction finished locally (locks/<d>/done): if Kamiak's A task is still pending, copy the files into the Kamiak
#    folder, cancel its A and C tasks and clear the dependency of its AD task (AD -> CD continue on Kamiak); if Kamiak
#    already ran it, keep Kamiak's result (the local one stays here as a cross-check);
#  - a direction that failed locally, or one held on Kamiak without a local claim: release its tasks.
set -uo pipefail
A_JOB=31541120; C_JOB=31541131; AD_JOB=31541132
KHOST=aryan.jha@kamiak.wsu.edu; KDIR=msopf/jobs/farkas_day148b_nov03/sfp1u_four
HERE="$(cd "$(dirname "$0")" && pwd)"; OUT="$HERE/sfp1u_four"; L="$HERE/locks"
k() { timeout 120 ssh -n -o BatchMode=yes -o ConnectTimeout=20 "$KHOST" "$@"; }
say() { echo "$(date '+%H:%M:%S') $*"; }
st=$(k "squeue -h -r -j $A_JOB -o '%K %T %r'") || { say "Kamiak unreachable"; exit 1; }
declare -A S; while read -r d s r; do [ -n "$d" ] && S[$d]="$s $r"; done <<< "$st"
for d in $(seq 2 78); do
    s=${S[$d]:-gone}
    [ -e "$L/$d/kamiak" ] && continue      # left to Kamiak (2026-11-03: the shared partition opened up)
    if [ -d "$L/$d" ]; then
        [ -e "$L/$d/synced" ] && continue
        if [ -e "$L/$d/done" ]; then
            if [ "${s%% *}" = PENDING ]; then
                (cd "$OUT" && scp -q -o BatchMode=yes fb_*_$d.csv "$KHOST:$KDIR/" && scp -q -o BatchMode=yes logs/A_$d.* logs/C_$d.* "$KHOST:$KDIR/logs/") \
                    && k "scancel ${A_JOB}_$d ${C_JOB}_$d; scontrol update JobId=${AD_JOB}_$d Dependency=" \
                    && { touch "$L/$d/synced"; say "dir $d: pushed; Kamiak A/C cancelled, AD released"; } || say "dir $d: push failed"
            else
                touch "$L/$d/synced"; echo "$s" > "$L/$d/kamiak_ran"; say "dir $d: Kamiak ran it too ($s); keeping Kamiak's"
            fi
        elif [ -e "$L/$d/failed" ]; then
            [ "$s" = "PENDING JobHeldUser" ] && k "scontrol release ${A_JOB}_$d ${C_JOB}_$d" && say "dir $d: failed locally; released on Kamiak"
            touch "$L/$d/synced"
        elif [ "${s%% *}" = PENDING ] && [ "$s" != "PENDING JobHeldUser" ]; then
            k "scontrol hold ${A_JOB}_$d ${C_JOB}_$d" && say "dir $d: running locally; held on Kamiak"
        fi
    elif [ "$s" = "PENDING JobHeldUser" ]; then
        k "scontrol release ${A_JOB}_$d ${C_JOB}_$d" && say "dir $d: held on Kamiak with no local claim; released"
    fi
done
