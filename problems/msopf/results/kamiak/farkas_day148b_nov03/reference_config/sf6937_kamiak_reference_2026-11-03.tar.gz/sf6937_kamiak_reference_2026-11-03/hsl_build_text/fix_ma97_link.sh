#!/bin/bash
#SBATCH --partition=vcea
#SBATCH --account=dubey
#SBATCH --job-name=hsl_ma97_link
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=00:30:00
#SBATCH --output=/home/aryan.jha/opt/hsl-private/logs/ma97_link_%j.out
set -euo pipefail
umask 077
ROOT=$HOME/opt/hsl-private
cd "$ROOT/build/hsl_ma97-2.8.1"
make clean > "$ROOT/logs/ma97_clean.log" 2>&1
bash configure --prefix="$ROOT/install/hsl_ma97-2.8.1" --with-blas=-lopenblas FC=gfortran F77=gfortran FFLAGS='-O2 -fPIC -fallow-argument-mismatch' FCFLAGS='-O2 -fPIC -fallow-argument-mismatch' LDFLAGS=-fopenmp > "$ROOT/logs/ma97_link_configure.log" 2>&1
make -C src -j2 libhsl_ma97.la > "$ROOT/logs/ma97_link_make.log" 2>&1
make install > "$ROOT/logs/ma97_link_install.log" 2>&1
ldd "$ROOT/install/hsl_ma97-2.8.1/lib/libhsl_ma97.so"
echo MA97_OPENMP_LINK_OK