#!/bin/bash
#SBATCH --partition=vcea
#SBATCH --account=dubey
#SBATCH --job-name=hsl_ipopt_check
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=12G
#SBATCH --time=00:30:00
#SBATCH --output=/home/aryan.jha/opt/hsl-private/logs/ipopt_check_%j.out
set -euo pipefail
umask 077
export PATH=$HOME/bin:$PATH
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 JULIA_NUM_THREADS=1
unset NO_COLOR FORCE_COLOR
ROOT=$HOME/opt/hsl-private
export REDUCED_PROFILE=periodic REDUCED_CB=system TERMINAL_SOC_SOFT=1
export IPOPT_SCREEN=substation,vupper,ell,psubs IPOPT_LOADFLOW_START=1 IPOPT_TRACE=1
cd "$HOME/MultiPeriodDistOPF"
for SOLVER in ma57 ma97; do
  if [ "$SOLVER" = ma57 ]; then
    LIB="$ROOT/install/ma57-3.11.3/lib/libma57.so"
    EXTRA='ma57_pivot_order=2'
    export LD_PRELOAD="$ROOT/install/ma57-3.11.3/lib/libfakemetis.so"
  else
    LIB="$ROOT/install/hsl_ma97-2.8.1/lib/libhsl_ma97.so"
    EXTRA='ma97_order=amd'
    export LD_PRELOAD="$ROOT/install/hsl_ma97-2.8.1/lib/libfakemetis.so"
  fi
  export IPOPT_EXTRA_OPTIONS="linear_solver=$SOLVER;hsllib=$LIB;linear_system_scaling=none;tol=1e-6;$EXTRA"
  export IPOPT_SAVE_DISPATCH="$ROOT/logs/dispatch_${SOLVER}_ieee123_T6.jls"
  LOG="$ROOT/logs/ipopt_${SOLVER}_ieee123_T6.log"
  julia --startup-file=no --project=envs/ddp2026 ddp/examples/power_system/centralized_ipopt_matched.jl ieee123C_1ph 6 "$ROOT/logs/internal_${SOLVER}.log" > "$LOG" 2>&1
  grep -E 'linear solver|CENTRAL_IPOPT|EXIT:|ERROR|Invalid_Option' "$LOG" | tail -10
  grep -q 'status=LOCALLY_SOLVED' "$LOG" || exit 1
  unset LD_PRELOAD
  bash ddp/examples/power_system/run_opendss_check.sh ieee123C_1ph 6 "$IPOPT_SAVE_DISPATCH" "kamiak_hsl_install_${SOLVER}_ieee123_T6" > "$ROOT/logs/opendss_${SOLVER}_ieee123_T6.log" 2>&1
  grep 'OPENDSS_SUMMARY' "$ROOT/logs/opendss_${SOLVER}_ieee123_T6.log"
done
echo HSL_IPOPT_CHECK_COMPLETE