#!/bin/bash
#SBATCH --partition=vcea
#SBATCH --account=dubey
#SBATCH --job-name=hsl_build
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=00:30:00
#SBATCH --output=/home/aryan.jha/opt/hsl-private/logs/build_%j.out
set -euo pipefail
umask 077
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2
ROOT=$HOME/opt/hsl-private
for PKG in ma57-3.11.3 hsl_ma97-2.8.1; do
  cd "$ROOT/build/$PKG"
  bash configure --prefix="$ROOT/install/$PKG" --with-blas=-lopenblas FC=gfortran F77=gfortran FFLAGS='-O2 -fPIC -fallow-argument-mismatch' FCFLAGS='-O2 -fPIC -fallow-argument-mismatch' > "$ROOT/logs/configure_$PKG.log" 2>&1
  if [ "$PKG" = hsl_ma97-2.8.1 ]; then make -C src -j2 libhsl_ma97.la > "$ROOT/logs/library_$PKG.log" 2>&1; fi
  make -j2 > "$ROOT/logs/make_$PKG.log" 2>&1
  make install > "$ROOT/logs/install_$PKG.log" 2>&1
  echo "BUILD_OK $PKG"
done