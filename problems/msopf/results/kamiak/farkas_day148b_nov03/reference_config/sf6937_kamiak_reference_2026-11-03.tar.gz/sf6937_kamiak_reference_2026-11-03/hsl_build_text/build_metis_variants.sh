#!/bin/bash
#SBATCH --partition=vcea
#SBATCH --account=dubey
#SBATCH --job-name=hsl_metis
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=00:30:00
#SBATCH --output=/home/aryan.jha/opt/hsl-private/logs/metis_%j.out
set -euo pipefail
umask 077
ROOT=$HOME/opt/hsl-private
cd "$ROOT/build/metis-4.0.3"
make -C Lib -j2 CC=gcc OPTFLAGS='-O2 -fPIC' > "$ROOT/logs/metis_build.log" 2>&1
mkdir -p "$ROOT/build/metis-variants"
for PKG in ma57-3.11.3 hsl_ma97-2.8.1; do
  if [ ! -d "$ROOT/build/metis-variants/$PKG" ]; then cp -a "$ROOT/build/$PKG" "$ROOT/build/metis-variants/$PKG"; fi
  cd "$ROOT/build/metis-variants/$PKG"
  make clean > "$ROOT/logs/metis_clean_$PKG.log" 2>&1
  bash configure --prefix="$ROOT/install/$PKG-metis" --with-blas=-lopenblasp --with-metis="$ROOT/build/metis-4.0.3/libmetis.a" FC=gfortran F77=gfortran FFLAGS='-O2 -fPIC -fallow-argument-mismatch' FCFLAGS='-O2 -fPIC -fallow-argument-mismatch' LDFLAGS=-fopenmp > "$ROOT/logs/metis_configure_$PKG.log" 2>&1
  if [ "$PKG" = hsl_ma97-2.8.1 ]; then make -C src -j2 libhsl_ma97.la > "$ROOT/logs/metis_library_$PKG.log" 2>&1; fi
  make -j2 > "$ROOT/logs/metis_make_$PKG.log" 2>&1
  make install > "$ROOT/logs/metis_install_$PKG.log" 2>&1
  echo "METIS_HSL_OK $PKG"
done