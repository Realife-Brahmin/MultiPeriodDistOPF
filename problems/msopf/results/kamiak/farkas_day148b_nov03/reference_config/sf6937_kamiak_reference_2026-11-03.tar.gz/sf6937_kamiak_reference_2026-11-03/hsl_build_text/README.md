# Private HSL installation on Kamiak (2026-10-14)

Sources supplied by Aryan: ma57-3.11.3.zip and hsl_ma97-2.8.1.zip.
Location: ~/opt/hsl-private; keep sources and binaries private and out of Git.

Installed libraries:
- install/ma57-3.11.3/lib/libma57.so
- install/hsl_ma97-2.8.1/lib/libhsl_ma97.so

Compiler: system gfortran. BLAS: LP64 system OpenBLAS (-lopenblas).
MA97: OpenMP enabled; explicitly link with LDFLAGS=-fopenmp.
MA97 package build workaround: make -C src libhsl_ma97.la before make install,
to generate module files required by the installation target.

Initial tests use AMD ordering, NOT METIS ordering. The supplied packages
include dummy METIS libraries; test_ipopt.sh preloads the corresponding
libfakemetis.so so the libraries load, while selecting AMD explicitly:
ma57_pivot_order=2; ma97_order=amd. Configure a compatible real METIS
before treating this as the tuned production benchmark configuration.

Scripts: build_hsl.sh, fix_ma97_link.sh, test_ipopt.sh.
Validation: matched IEEE123 T=6, periodic profile, C_B=system, soft terminal
SOC, screened model, loadflow start, Ipopt tol=1e-6, OpenDSS replay.
Results and compilation diagnostics are retained under logs/.
These are installation/correctness checks, not controlled timing benchmarks.
Reinstallation is not needed per job; load the installed library by hsllib.