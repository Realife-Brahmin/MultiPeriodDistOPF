#!/bin/bash
set -euo pipefail
R=$HOME/opt/hsl-private
D=$R/build/hsl_ma97-2.8.1-openmp
test ! -e "$D"
cp -a "$R/build/metis-variants/hsl_ma97-2.8.1" "$D"
cd "$D"
make distclean
./configure --prefix="$R/install/hsl_ma97-2.8.1-metis-openmp" --with-blas=-lopenblasp --with-metis="$R/build/metis-4.0.3/libmetis.a" FC=gfortran F77=gfortran FFLAGS='-O2 -fPIC -fallow-argument-mismatch -fopenmp' FCFLAGS='-O2 -fPIC -fallow-argument-mismatch -fopenmp' LDFLAGS=-fopenmp
make -C src -j2 libhsl_ma97.la
make -j2 install
nm -D "$R/install/hsl_ma97-2.8.1-metis-openmp/lib/libhsl_ma97.so" | grep GOMP
echo OPENMP_BUILD_COMPLETE
