from pathlib import Path
p=Path("dense_kernel_study/replay.jl")
s=p.read_text()
s=s.replace('        STUDY_KERNEL[] = kernel\n        STUDY_DIAGNOSTIC[] = diagnostic',
'''        parts=split(kernel,'_')
        threads=length(parts)==2 ? parse(Int,parts[2]) : parse(Int,ENV["STUDY_BLAS_THREADS"])
        STUDY_KERNEL[] = parts[1]
        STUDY_DIAGNOSTIC[] = diagnostic
        BLAS.set_num_threads(threads)''')
s=s.replace('        nothing\n    end\n    function study_pin', '''        threads
    end
    function study_pin''',1)
s=s.replace('        @sync for p in pids\n            @async remotecall_fetch(study_configure,p,scheduling,rep == -1)\n        end',
'''        threads=length(split(scheduling,'_'))==2 ? parse(Int,split(scheduling,'_')[2]) : parse(Int,ENV["STUDY_BLAS_THREADS"])
        maps=readlines(joinpath(ROOT,"cpu_groups_$threads.csv"))
        @sync for (j,p) in enumerate(pids)
            @async begin
                remotecall_fetch(study_configure,p,scheduling,rep<0)
                placement=remotecall_fetch(study_pin,p,maps[j+1])
                println("CONFIG rep=$rep mode=$scheduling info=$placement")
            end
        end''')
s=s.replace('vcat(collect(0:5),[-1])','vcat(collect(0:5),[-2,-1])')
# A fresh worker scratch object equals the original two-matrix PairWork.
s=s.replace('println("SHARED_BYTES ",8N*(3n*n+2n))','println("SHARED_BYTES ",8N*(3n*n+2n))\n    println("SCRATCH_OBJECT_BYTES ",remotecall_fetch(p->Base.summarysize(REPLAY_WORK[]),pids[1],0))')
p.write_text(s)
