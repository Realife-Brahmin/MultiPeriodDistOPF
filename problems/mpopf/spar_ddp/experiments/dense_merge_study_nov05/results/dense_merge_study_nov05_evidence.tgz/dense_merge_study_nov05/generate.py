from pathlib import Path
source = Path(r"C:/Users/Aryan Ritwajeet Jha/Documents/documents_general/MultiPeriodDistOPF/.codex/worktrees/pr171-tree-ablation/problems/mpopf/spar_ddp/results/balanced_stage_b/grouped_replay/replay.jl").read_text()
source=source.replace('const MAXW = MULTI ? 96 : 63','const MAXW = parse(Int, ENV["STUDY_WORKERS"])')
source=source.replace('    BLAS.set_num_threads(1)','    BLAS.set_num_threads(parse(Int, ENV["STUDY_BLAS_THREADS"]))')
source=source.replace('    const REPLAY_INPUT', '''    include(joinpath(ENV["REPLAY_ROOT"], "right_kernel.jl"))
    const STUDY_KERNEL = Ref("current")
    const STUDY_DIAGNOSTIC = Ref(false)
    function study_configure(kernel, diagnostic)
        STUDY_KERNEL[] = kernel
        STUDY_DIAGNOSTIC[] = diagnostic
        nothing
    end
    function study_pin(cpus)
        run(pipeline(`taskset -apc $cpus $(getpid())`; stdout=devnull))
        (pid=myid(),os_pid=getpid(),cpus=cpus,blas_threads=BLAS.get_num_threads(),
         backend=string(BLAS.get_config()),
         thread_status=read(`ps -L -p $(getpid()) -o pid,tid,psr,comm`,String))
    end
    const REPLAY_INPUT''',1).replace("\`","`")
source=source.replace('        z=_pp_combine!(x,y,REPLAY_WORK[])','''        if STUDY_DIAGNOSTIC[]
            measurement = @timed (STUDY_KERNEL[] == "right" ?
                right_combine!(x,y,REPLAY_WORK[]) : _pp_combine!(x,y,REPLAY_WORK[]))
            z = measurement.value
            bytes_allocated = measurement.bytes
            compile_s = measurement.compile_time + measurement.recompile_time
        else
            z = STUDY_KERNEL[] == "right" ? right_combine!(x,y,REPLAY_WORK[]) :
                _pp_combine!(x,y,REPLAY_WORK[])
            bytes_allocated = -1
            compile_s = -1.0
        end''')
source=source.replace('pid=myid())','pid=myid(),allocated=bytes_allocated,compile_s=compile_s)',1)
source=source.replace('hosts=Dict', '''BLAS.set_num_threads(1)
cpulines = readlines(joinpath(ROOT,"cpu_groups.csv"))
@assert length(cpulines) == MAXW+1
run(pipeline(`taskset -apc $(cpulines[1]) $(getpid())`; stdout=devnull))
for (j,p) in enumerate(workers())
    println("AFFINITY ",remotecall_fetch(study_pin,p,cpulines[j+1]))
end
hosts=Dict''').replace("\`","`")
source=source.replace('counts=[63]','counts=[MAXW]')
source=source.replace('totals=Dict("grouped"=>Float64[],"balanced"=>Float64[])','''kernels=split(get(ENV,"STUDY_KERNELS","current,right"),',')
    totals=Dict(k=>Float64[] for k in kernels)''')
source=source.replace('    for rep in 0:5, scheduling in (iseven(rep) ? ("grouped","balanced") : ("balanced","grouped"))','''    for rep in vcat(collect(0:5),[-1]), scheduling in (iseven(rep) ? kernels : reverse(kernels))
        @sync for p in pids
            @async remotecall_fetch(study_configure,p,scheduling,rep == -1)
        end''')
source=source.replace('rounds=replay_rounds(N,scheduling=="grouped" ? 2 : 1)','rounds=replay_rounds(N,2)')
source=source.replace('(scheduling=="grouped" ? (256,8) : (368,7))','(256,8)')
source=source.replace('rr=Vector{Any}(undef,length(pairs)); rt=time_ns()','rr=Vector{Any}(undef,length(pairs)); finished=zeros(UInt64,length(pairs)); rt=time_ns()')
source=source.replace('                @async rr[q]=remotecall_fetch(replay_combine,assigned[q],t,mid,valid[mid],mid==N+1,mid==N+1 ? owner[t] : owner[mid],shared)','''                @async begin
                    rr[q]=remotecall_fetch(replay_combine,assigned[q],t,mid,valid[mid],mid==N+1,mid==N+1 ? owner[t] : owner[mid],shared)
                    finished[q]=time_ns()
                end''')
source=source.replace('push!(roundstats,(round,elapsed,assigned,rr))','push!(roundstats,(round,elapsed,assigned,rr,finished))')
source=source.replace('for (round,wall,assigned,rr) in roundstats','''for (round,wall,assigned,rr,finished) in roundstats
            worker_time=[sum((rr[q].compute for q in eachindex(assigned) if assigned[q]==p); init=0.0) for p in pids]
            println("ROUND_DETAIL mode=$scheduling rep=$rep round=$round kernel_sum_s=$(sum(worker_time)) busiest_s=$(maximum(worker_time)) allocation_bytes=$(sum(r.allocated for r in rr)) gc_s=$(sum(r.gc for r in rr)) compile_s=$(sum(r.compile_s for r in rr)) completion_spread_s=$((maximum(finished)-minimum(finished))/1e9)")''')
source=source.replace('for scheduling in ("grouped","balanced")','for scheduling in kernels')
Path("dense_kernel_study/replay.jl").write_text(source)
late = Path(r"C:/Users/Aryan Ritwajeet Jha/Documents/documents_general/MultiPeriodDistOPF/.codex/worktrees/pr171-tree-ablation/problems/mpopf/spar_ddp/results/balanced_stage_b/grouped_replay/late.jl").read_text()
late=late.replace('function check_late(cap)','include(joinpath(@__DIR__, "right_kernel.jl"))\nBLAS.set_num_threads(parse(Int,get(ENV,"STUDY_BLAS_THREADS","1")))\nfunction check_late(cap)')
late=late.replace('xs[i]=_pp_combine!(xs[i],xs[j],work)','xs[i]=right_combine!(xs[i],xs[j],work)')
Path("dense_kernel_study/late.jl").write_text(late)
