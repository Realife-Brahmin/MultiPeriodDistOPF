#!/usr/bin/env bash
# Centralized Ipopt with HSL MA57 / HSL_MA97 against its default MUMPS, on the
# nine Table II instances at the per-system C_B (agenda of 2026-10-02). The HSL
# libraries are built locally from the user's licensed sources
# (hsl/build_hsl_windows.sh) and loaded through Ipopt's hsllib option; they are
# not in this repository. MC19 is not in the licensed packages, so every run
# uses linear_system_scaling = none (MUMPS included, for a like-for-like
# comparison). MA97 runs on 1 and on 8 OpenMP threads; MUMPS is Ipopt's
# sequential build. One case at a time, background load logged.
#
# BLAS1=1 pins OpenBLAS (which MUMPS, MA57 and MA97 all call) to one thread
# and tags the logs _blas1, so the only parallelism left is MA97's OpenMP.
#
#   bash spar_ddp/examples/power_system/run_ipopt_hsl.sh
#
# OPENDSS_CHECK=1 (default since 2026-10-11): each solve keeps its dispatch
# (written after the solve, outside its timer) and OpenDSS checks it before
# the next case starts, as run_parsim.sh does for FilterDDP. OPENDSS_CHECK=0
# skips both.

set -u
cd "$(dirname "$0")/../../.." || exit 1
HSL="${HSL_LIB_DIR:-C:/Users/Aryan Ritwajeet Jha/Documents/hsl/build}"
OUT=spar_ddp/results/ipopt_hsl
mkdir -p "$OUT/logs"
TAG=""
if [ "${BLAS1:-0}" = 1 ]; then export OPENBLAS_NUM_THREADS=1; TAG=_blas1; fi
# IPOPT_TAG_SUFFIX names a variant of the model, e.g. _screen_lf for runs with
# IPOPT_SCREEN and IPOPT_LOADFLOW_START set (centralized_ipopt_matched.jl).
TAG="${TAG}${IPOPT_TAG_SUFFIX:-}"
export REDUCED_PROFILE=periodic REDUCED_CB=system TERMINAL_SOC_SOFT=1
export PATH="$HSL:$PATH"
JL="julia --startup-file=no"
LOADJL=spar_ddp/examples/power_system/sample_background_load.jl

# CELLS="system:T ..." and SOLVERS="ma57 ma97 ..." override the defaults (the
# Table II cells, all four solvers). A missing periodic instance is exported
# first (export_ieee123c_data.jl, PROFILE_PERIODIC=1).
CELLS=${CELLS:-"ieee123C_1ph:6 ieee123C_1ph:24 ieee123C_1ph:96 ieee2522C_1ph:6 ieee2522C_1ph:24 ieee2522C_1ph:96 large10kC_1ph:6 large10kC_1ph:24 large10kC_1ph:48"}
SOLVERS=${SOLVERS:-"mumps ma57 ma97 ma97t8"}
for cell in $CELLS; do
  S=${cell%%:*}; T=${cell##*:}
  DATA="spar_ddp/results/network_filterddp/network_data_${S}_T${T}_periodic.jls"
  if [ ! -s "$DATA" ]; then
    PROFILE_PERIODIC=1 $JL --project=envs/tadmm spar_ddp/examples/power_system/export_ieee123c_data.jl "$S" "$T" \
      > "$OUT/logs/export_${S}_T${T}.log" 2>&1
    [ -s "$DATA" ] || { echo "export failed for $S T=$T"; continue; }
  fi
  for LS in $SOLVERS; do
    case $LS in
      mumps)  OPTS="linear_system_scaling=none"; OMP=1;;
      ma57)   OPTS="linear_solver=ma57;hsllib=$HSL/libma57.dll;linear_system_scaling=none"; OMP=1;;
      ma97)   OPTS="linear_solver=ma97;hsllib=$HSL/libhsl_ma97.dll;linear_system_scaling=none"; OMP=1;;
      ma97t8) OPTS="linear_solver=ma97;hsllib=$HSL/libhsl_ma97.dll;linear_system_scaling=none"; OMP=8;;
      ma97t4) OPTS="linear_solver=ma97;hsllib=$HSL/libhsl_ma97.dll;linear_system_scaling=none"; OMP=4;;
    esac
    LOG="$OUT/logs/ipopt_${LS}${TAG}_${S}_T${T}.log"
    [ -s "$LOG" ] && grep -q "CENTRAL_IPOPT " "$LOG" && { echo "skip $LS $S T=$T"; continue; }
    $JL "$LOADJL" wait 10 1.5 2>/dev/null | grep QUIET_WAIT > "$LOG"
    STOP="$OUT/logs/.sampling_$$"; touch "$STOP"
    $JL "$LOADJL" sample "$STOP" "$OUT/logs/load_${LS}${TAG}_${S}_T${T}.csv" 15 > /dev/null 2>&1 &
    SPID=$!
    # IPOPT_MORE_OPTIONS adds to every solver's options, e.g. "tol=1e-6".
    OPTS="$OPTS${IPOPT_MORE_OPTIONS:+;$IPOPT_MORE_OPTIONS}"
    RUNTAG="ipopt_${LS}${TAG}_${S}_T${T}"
    if [ "${OPENDSS_CHECK:-1}" = 1 ]; then
      SOLDIR=spar_ddp/results/kkt_ordering/captures/solutions; mkdir -p "$SOLDIR"
      export IPOPT_SAVE_DISPATCH="$SOLDIR/sol_$RUNTAG.jls"; rm -f "$IPOPT_SAVE_DISPATCH"
    else
      unset IPOPT_SAVE_DISPATCH
    fi
    IPOPT_EXTRA_OPTIONS="$OPTS" OMP_NUM_THREADS=$OMP \
      $JL --project=envs/spar_ddp spar_ddp/examples/power_system/centralized_ipopt_matched.jl \
      "$S" "$T" "$OUT/logs/ipopt_${LS}${TAG}_${S}_T${T}_ipoptlog.txt" >> "$LOG" 2>&1
    rm -f "$STOP"; wait "$SPID" 2>/dev/null
    echo "[$(date '+%H:%M:%S')] $LS$TAG $(grep -oE 'CENTRAL_IPOPT system=\S+ T=[0-9]+ .*status=\S+ iterations=[0-9]+ objective=\S+ solve_time_s=\S+' "$LOG")"
    if [ "${OPENDSS_CHECK:-1}" = 1 ]; then
      if [ -s "$IPOPT_SAVE_DISPATCH" ]; then
        bash spar_ddp/examples/power_system/run_opendss_check.sh "$S" "$T" "$IPOPT_SAVE_DISPATCH" "$RUNTAG" 2>&1 \
          | grep -E "OPENDSS_SUMMARY|FAILED" | cut -c1-330
      else
        echo "OPENDSS_CHECK: no dispatch saved by this run ($RUNTAG)"
      fi
    fi
  done
done
echo "IPOPT_HSL_DONE"
