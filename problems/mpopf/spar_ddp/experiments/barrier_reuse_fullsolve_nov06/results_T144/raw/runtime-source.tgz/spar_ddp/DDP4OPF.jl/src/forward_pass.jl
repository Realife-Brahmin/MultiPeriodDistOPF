# Which bound stops the step. The line search halves the step whenever a trial
# point breaks the fraction-to-boundary rule (status 2); those halvings are not
# counted in `data.l`. With FILTERDDP_FTB_DIAGNOSTIC=1 every such rejection is
# printed: the stage, which of the four tests failed (control at its lower or
# upper bound, or the multiplier of one), how many entries failed, and the
# worst entry with its slack before and after. Read-only: no effect on iterates.
_ftb_diagnostic() = get(ENV, "FILTERDDP_FTB_DIAGNOSTIC", "0") != "0"
function _ftb_report(data, t::Int, kind::String, before, after, tau, mask)
    worst = 0; ratio = Inf; n = 0
    for i in eachindex(before)
        (mask === nothing || mask[i]) || continue
        before[i] * (1. - tau) > after[i] || continue
        n += 1
        r = after[i] / before[i]
        r < ratio && (ratio = r; worst = i)
    end
    @printf("FILTERDDP_FTB iteration=%d step=%.6e stage=%d kind=%s failed=%d worst_index=%d before=%.6e after=%.6e\n",
            data.k, data.step_size, t, kind, n, worst, before[worst], after[worst])
    return nothing
end

function forward_pass!(solver::Solver{T, nx, nu, nc, nux, ncx},
            ocp::OCP{T, nx, nu, nc}, data::SolverData{T},
            options::Options{T}; verbose=false) where {T, nx, nu, nc, nux, ncx}
    data.l = 0  # line search iteration counter
    data.status = 0
    data.step_size = T(1.0)
    _parsim() && fill!(_PARSIM_FWD, 0.0)
    ΔL = data.expected_change_L
    μ = data.μ
    τ = max(options.τ_min, T(1.0) - μ)
    # Affine dynamics: directions from one unit-step rollout, and the largest
    # step the fraction-to-boundary rule allows (affine_linesearch.jl).
    aff = nothing
    if _affine_linesearch()
        directions_hook = AFFINE_DIRECTIONS_HOOK[]
        isnothing(directions_hook) || (aff = directions_hook(solver, ocp, data, τ))
        aff === nothing && (aff = affine_directions(solver, ocp, data, τ))
    end
    aff === nothing || (data.step_size = aff.γmax)

    θ_prev = data.primal_1_curr
    L_prev = data.barrier_lagrangian_curr
    
    while data.step_size >= eps(T)
        γ = data.step_size
        if aff === nothing
            rollout!(solver, ocp, data, τ, γ)
        else
            rollout_hook = AFFINE_ROLLOUT_HOOK[]
            (isnothing(rollout_hook) || !rollout_hook(solver, ocp, data, aff, γ)) &&
                affine_rollout!(solver, ocp, data, aff, γ)
        end
        data.status != 0 && (data.step_size *= 0.5, continue)
        
        # used for sufficient decrease from current iterate step acceptance criterion
        θ = data.primal_1_next
        L = data.barrier_lagrangian_next

        # check acceptability to filter
        data.status = !any(x -> (θ >= x[1] && L >= x[2]), data.filter) ? 0 : 3
        data.status != 0 && (data.step_size *= 0.5, data.l += 1, continue)  # failed, reduce step size
        
        # check for sufficient decrease conditions for the barrier objective/constraint violation
        data.switching = (ΔL < 0.0) && 
            ((-γ * ΔL) ^ options.s_L * γ^(1-options.s_L)  > options.δ * θ_prev ^ options.s_θ)
        data.armijo_passed = L - L_prev - 10. * eps(Float64) * abs(L_prev) <= options.η_L * γ * ΔL
        if (θ <= data.min_primal_1) && data.switching
            data.status = data.armijo_passed ? 0 : 4  #  sufficient decrease of barrier objective
        else
            suff = (θ <= (1. - options.γ_θ) * θ_prev) || (L <= L_prev - options.γ_L * θ_prev)
            data.status = suff ? 0 : 5
        end
        data.status != 0 && (data.step_size *= 0.5, data.l += 1, continue)  # failed, reduce step size
        break
    end
    _parsim() && @printf(
        "FILTERDDP_PARSIM_FORWARD iteration=%d dir_sum_s=%.9f dir_max_s=%.9f rec_s=%.9f rec_err=%.3e trials=%d trial_sum_s=%.9f trial_max_s=%.9f gc_s=%.9f stages=%d\n",
        data.k, _PARSIM_FWD[1], _PARSIM_FWD[2], _PARSIM_FWD[3], _PARSIM_FWD[4],
        Int(_PARSIM_FWD[5]), _PARSIM_FWD[6], _PARSIM_FWD[7], _PARSIM_FWD[8], ocp.N)
    data.step_size < eps(T) && (data.status = 7)
    data.status != 0 && (verbose && (@warn "Line search failed to find a suitable iterate"))
end

function rollout!(solver::Solver{T, nx, nu, nc, nux, ncx}, ocp::OCP{T, nx, nu, nc},
            data::SolverData{T}, τ::T, step_size::T) where {T, nx, nu, nc, nux, ncx}
    μ = data.μ
    cl = ocp.control_limits

    data.status = 0
    data.primal_1_next = T(0.0)
    data.barrier_lagrangian_next = T(0.0)

    x = solver.nominal[1].x
    for t = 1:ocp.N

        x̄ = solver.nominal[t].x
        ū = solver.nominal[t].u
        ϕ̄  = solver.nominal[t].ϕ
        α = solver.update[t].α
        ψ = solver.update[t].ψ
        update_rule = solver.update[t]
        zl̄ = solver.nominal[t].zl
        zū = solver.nominal[t].zu
        χl = solver.update[t].χl
        χu = solver.update[t].χu
        Σ_L = solver.update[t].Σ_L
        Σ_U = solver.update[t].Σ_U

        δx = x - x̄

        βδx, ωδx = policy_actions!(update_rule, δx)
        u = ū + step_size .* α + βδx
        ϕ = ϕ̄  + step_size .* ψ + ωδx
        zl = zl̄ + step_size .* χl - Σ_L .* βδx
        zu = zū + step_size .* χu + Σ_U .* βδx
        
        # update current trajectory
        solver.current[t] = TrajectoryElement{T, nx, nu, nc}(x, u, ϕ, zl, zu)

        # evaluate constraints and violation
        if nc > 0
            c = stage_con(ocp, t).c(x, u)
            data.primal_1_next += norm(c, 1)
            data.barrier_lagrangian_next += dot(c, ϕ)
        end

        # check frac-to-boundary condition
        ul = u - cl.l
        uu = cl.u - u
        ul̄ = ū - cl.l
        uū = cl.u - ū

        if any((ul̄ .* (1. - τ) .> ul) .* cl.maskl)
            data.status = 2
            _ftb_diagnostic() && _ftb_report(data, t, "control_lower", ul̄, ul, τ, cl.maskl)
            return
        end
        if any((uū .* (1. - τ) .> uu) .* cl.masku)
            data.status = 2
            _ftb_diagnostic() && _ftb_report(data, t, "control_upper", uū, uu, τ, cl.masku)
            return
        end
        if any(zl̄ .* (1. - τ) .> zl)
            data.status = 2
            _ftb_diagnostic() && _ftb_report(data, t, "multiplier_lower", zl̄, zl, τ, nothing)
            return
        end
        if any(zū .* (1. - τ) .> zu)
            data.status = 2
            _ftb_diagnostic() && _ftb_report(data, t, "multiplier_upper", zū, zu, τ, nothing)
            return
        end

        # evaluate barrier lagrangian
        data.barrier_lagrangian_next -= μ * dot(log.(ul), cl.maskl)
        data.barrier_lagrangian_next -= μ * dot(log.(uu), cl.masku)
        if t == ocp.N
            data.barrier_lagrangian_next += ocp.term_objective.l(x, u)[1]
        else
            data.barrier_lagrangian_next += stage_obj(ocp, t).l(x, u)[1]
        end

        if t < ocp.N
            x = solver.ocp.dynamics.f(x, u)
        end
    end
end
