#!/usr/bin/env bash
# Follow-up to run_table2_screen.sh: every earlier iteration-dependent result
# was measured with the line search throttled by the substation voltage bound
# (spar_ddp/notes/CONSTRAINT_SCREENING.md), so the cases that fed a conclusion are
# rerun in the new configuration (screening + power-flow start + exact step),
# compilation excluded by a warm-up (a full first solve on the Table II
# cells, 8 iterations at long horizons). One run at a time, quiet machine, full
# per-iteration logs. Completed logs are skipped.
#
#   E. ieee123 and med2522 Table II cells to the solver's own tolerance.
#      Near-optimality is now declared much earlier on the barrier path
#      (objective gap up to 0.34% against 1e-5 before), so the like-for-like
#      figure is the time to a given gap, read from these logs afterwards
#      (near_opt_posthoc.py);
#   A. longer horizons, diagonal Hessian, tree solver: med2522 T=192, 384 and
#      large10k T=96, 192, with Ipopt (MA57, MA97) on the same model and start;
#   B. exact Hessian through the tree solver on the Table II cells;
#   C. C_B = 0 with the diagonal Hessian, where it failed before
#      (large10k T=6, med2522 T=96);
#   D. med2522 T=1152, and T=1536 (failed before; no Ipopt reference, strict).
#
# large10k runs use the instance corrected on 2026-10-05 (PV restored, see
# run_large10k_pv_rerun.sh, which also covers its Table II cells) and carry
# the tag `pv`; their near-optimality references are Ipopt runs on that
# instance.
#
# Waits for the file given as $1 to contain TABLE2_SCREEN_DONE (or for no
# julia.exe if no argument). PARTS="A B" selects parts.
#
#   bash spar_ddp/examples/power_system/run_screen_followup.sh [wait_file]

set -u
cd "$(dirname "$0")/../../.." || exit 1
if [ -n "${1:-}" ]; then until grep -q TABLE2_SCREEN_DONE "$1" 2>/dev/null; do sleep 30; done; fi
until [ "$(tasklist //FI "IMAGENAME eq julia.exe" 2>/dev/null | grep -c julia.exe)" = "0" ]; do sleep 30; done
echo "[$(date '+%H:%M:%S')] follow-up start"
PARTS="${PARTS:-E A B C D}"
S=spar_ddp/examples/power_system/run_blocked_solve_fullrun.sh
H=spar_ddp/results/ipopt_hsl/logs
SCREEN=substation,vupper,ell,psubs
export PIN_BLAS_THREADS=0 VARIANTS=blocked_w16 CB=system
export FILTERDDP_DIRECT_DIAG_HESSIAN=1 FILTERDDP_TRIPLET_SECOND_DERIVATIVES=1 FILTERDDP_CACHE_KKT_PATTERN=1
export FILTERDDP_FACTOR_BACKED_POLICY=1 FILTERDDP_TYPED_EQUATIONS=1 FILTERDDP_STRUCTURED_DYNAMICS=1
export FILTERDDP_SCREEN=$SCREEN FILTERDDP_LOADFLOW_START=1 FILTERDDP_AFFINE_LINESEARCH=1
export FILTERDDP_TREE_KKT=1 JULIA_NUM_THREADS=8

for part in $PARTS; do case $part in
E)
  export STRICT=1
  for cell in ieee123C_1ph:6:full ieee123C_1ph:24:full ieee123C_1ph:96:full ieee2522C_1ph:6:full ieee2522C_1ph:24:full ieee2522C_1ph:96:8; do
    IFS=: read sys T warm <<< "$cell"
    export FILTERDDP_WARMUP=$warm
    case $sys in
      ieee123C_1ph) unset FILTERDDP_TREE_KKT; export JULIA_NUM_THREADS=1 RUN_TAG_SUFFIX=_tableII_cbsys_typed_sd_screen_warm_strict;;
      *)            export FILTERDDP_TREE_KKT=1 JULIA_NUM_THREADS=8 RUN_TAG_SUFFIX=_tableII_jt8_cbsys_typed_tree3_screen_warm_strict;;
    esac
    bash "$S" "$sys" "$T" diag 16 1
  done
  unset STRICT
  export FILTERDDP_TREE_KKT=1 JULIA_NUM_THREADS=8
  ;;
A)
  IPOPT_SCREEN=$SCREEN IPOPT_LOADFLOW_START=1 IPOPT_TAG_SUFFIX=_screen_lf SOLVERS="ma57 ma97" \
    CELLS="ieee2522C_1ph:192 ieee2522C_1ph:384" bash spar_ddp/examples/power_system/run_ipopt_hsl.sh
  IPOPT_SCREEN=$SCREEN IPOPT_LOADFLOW_START=1 IPOPT_TAG_SUFFIX=_screen_lf_pv SOLVERS="ma57 ma97" \
    CELLS="large10kC_1ph:96 large10kC_1ph:192" bash spar_ddp/examples/power_system/run_ipopt_hsl.sh
  export FILTERDDP_WARMUP=8
  RUN_TAG_SUFFIX=_jt8_cbsys_typed_tree3_screen_warm IPOPT_REF_LOG=$H/ipopt_ma57_ieee2522C_1ph_T192.log \
    bash "$S" ieee2522C_1ph 192 diag 16 1
  RUN_TAG_SUFFIX=_jt8_cbsys_typed_tree3_screen_warm_pv IPOPT_REF_LOG=$H/ipopt_ma57_screen_lf_pv_large10kC_1ph_T96.log \
    bash "$S" large10kC_1ph 96 diag 16 1
  RUN_TAG_SUFFIX=_jt8_cbsys_typed_tree3_screen_warm IPOPT_REF_LOG=$H/ipopt_oom_ma57_ieee2522C_1ph_T384.log \
    bash "$S" ieee2522C_1ph 384 diag 16 1
  RUN_TAG_SUFFIX=_jt8_cbsys_typed_tree3_screen_warm_pv IPOPT_REF_LOG=$H/ipopt_ma57_screen_lf_pv_large10kC_1ph_T192.log \
    bash "$S" large10kC_1ph 192 diag 16 1
  ;;
B)
  export FILTERDDP_WARMUP=full
  for cell in ieee123C_1ph:6 ieee123C_1ph:24 ieee123C_1ph:96 ieee2522C_1ph:6 ieee2522C_1ph:24 \
              ieee2522C_1ph:96 large10kC_1ph:6 large10kC_1ph:24; do
    sys=${cell%%:*}; T=${cell##*:}
    case $sys in
      ieee123C_1ph)  JULIA_NUM_THREADS=1 RUN_TAG_SUFFIX=_tableII_cbsys_typed_tree4_screen_warm bash "$S" "$sys" "$T" exact 16 1;;
      large10kC_1ph) RUN_TAG_SUFFIX=_tableII_jt8_cbsys_typed_tree4_screen_warm_pv \
                       IPOPT_REF_LOG=$H/ipopt_ma57_screen_lf_pv_large10kC_1ph_T$T.log bash "$S" "$sys" "$T" exact 16 1;;
      *)             RUN_TAG_SUFFIX=_tableII_jt8_cbsys_typed_tree4_screen_warm bash "$S" "$sys" "$T" exact 16 1;;
    esac
  done
  ;;
C)
  export FILTERDDP_WARMUP=full
  # C_B = 0 reference for large10k on the corrected instance
  NOCB=spar_ddp/results/ipopt_no_cb/logs/ipopt_nocb_pv_large10kC_1ph_T6.log
  if ! grep -q "CENTRAL_IPOPT " "$NOCB" 2>/dev/null; then
    HSL="${HSL_LIB_DIR:-C:/Users/Aryan Ritwajeet Jha/Documents/hsl/build}"
    PATH="$HSL:$PATH" REDUCED_PROFILE=periodic REDUCED_CB=0 TERMINAL_SOC_SOFT=1 \
    IPOPT_EXTRA_OPTIONS="linear_solver=ma57;hsllib=$HSL/libma57.dll;linear_system_scaling=none" \
      julia --startup-file=no --project=envs/spar_ddp spar_ddp/examples/power_system/centralized_ipopt_matched.jl \
      large10kC_1ph 6 "${NOCB%.log}_ipoptlog.txt" > "$NOCB" 2>&1
  fi
  CB=0 RUN_TAG_SUFFIX=_tableII_jt8_cb0_typed_tree3_screen_warm_pv IPOPT_REF_LOG=$NOCB bash "$S" large10kC_1ph 6 diag 16 1
  CB=0 RUN_TAG_SUFFIX=_tableII_jt8_cb0_typed_tree3_screen_warm bash "$S" ieee2522C_1ph 96 diag 16 1
  ;;
D)
  export FILTERDDP_WARMUP=8 RUN_TAG_SUFFIX=_jt8_cbsys_typed_tree3_screen_warm
  IPOPT_REF_LOG=$H/ipopt_oom_ma57_ieee2522C_1ph_T1152.log bash "$S" ieee2522C_1ph 1152 diag 16 1
  LOG=spar_ddp/results/kkt_ordering/fullrun_blocked/fddp_ieee2522C_1ph_T1536_diag_jt8_cbsys_typed_tree3_screen_warm_strict_r1.log
  if ! grep -q "solve complete" "$LOG" 2>/dev/null; then
    REDUCED_PROFILE=periodic REDUCED_CB=system TERMINAL_SOC_SOFT=1 FILTERDDP_MAX_ITERATIONS=400 \
    FILTERDDP_TIMING_DIAGNOSTIC=1 FILTERDDP_FEASIBILITY_DIAGNOSTIC=1 FILTERDDP_DIAG_HESSIAN=1 \
    FILTERDDP_DIAG_HESSIAN_FLOOR=1e-8 FILTERDDP_BLOCKED_SOLVE=16 FILTERDDP_SKIP_SOLUTION_WRITE=1 \
      julia --startup-file=no --project=envs/spar_ddp spar_ddp/examples/power_system/ieee123c_filterddp.jl \
      ieee2522C_1ph 1536 solve > "$LOG" 2>&1
    echo "[$(date '+%H:%M:%S')] ieee2522C_1ph_T1536 strict: $(grep -E 'solve complete' "$LOG") | $(grep -oE 'FilterDDP objective=\S+' "$LOG") | $(grep -oE 'maxrss_mib=\S+' "$LOG")"
  fi
  ;;
esac; done
echo "[$(date '+%H:%M:%S')] SCREEN_FOLLOWUP_DONE"
