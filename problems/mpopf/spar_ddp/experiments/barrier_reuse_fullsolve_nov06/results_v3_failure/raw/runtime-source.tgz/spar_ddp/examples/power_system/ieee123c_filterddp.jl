using SHA
# Direct FilterDDP transcription of the tADMM workspace's IEEE123C BFM-SOCP.
#
# The network algebraic variables are FilterDDP controls. The only states are
# battery energies. Inequalities unsupported by FilterDDP are represented as
# box-bounded controls, or as equality constraints with nonnegative slacks.
#
# Run after export_ieee123c_data.jl:
#   julia --startup-file=no --project=envs/spar_ddp \
#         spar_ddp/examples/power_system/ieee123c_filterddp.jl \
#         [system] [T] [dimensions|build|solver|solve]

using DDP4OPF
using JuMP
using LinearAlgebra
using Printf
using Serialization
using SparseArrays

const REPO = normpath(joinpath(@__DIR__, "..", "..", ".."))
include(joinpath(@__DIR__, "terminal_soc_penalty.jl"))
include(joinpath(@__DIR__, "voltage_screening.jl"))
include(joinpath(@__DIR__, "loadflow_start.jl"))
get(ENV, "FILTERDDP_BATTERY_SCHUR", "0") != "0" &&
    include(joinpath(@__DIR__, "battery_schur_hook.jl"))
get(ENV, "FILTERDDP_TREE_KKT", "0") != "0" && include(joinpath(@__DIR__, "tree_kkt.jl"))
get(ENV, "FILTERDDP_PINT_SCAN", "0") != "0" && include(joinpath(@__DIR__, "pint_scan.jl"))
# FILTERDDP_THREADED=1: the backward and forward passes with the periods on
# Julia threads (threaded_pass.jl); needs the tree solver.
get(ENV, "FILTERDDP_THREADED", "0") != "0" && include(joinpath(@__DIR__, "threaded_pass.jl"))

include(joinpath(@__DIR__, "control_layout.jl"))

function analytic_dynamics(nx, nu, pbidx, dt)
    f = (x,u) -> x .- dt .* u[pbidx]
    # The battery dynamics are x - dt*P_B: f_x is the identity. With
    # FILTERDDP_STRUCTURED_DYNAMICS=1 it is returned sparse, so products such as
    # f_x' V_xx f_x cost a copy instead of two dense n_x^3 multiplications.
    fx = get(ENV, "FILTERDDP_STRUCTURED_DYNAMICS", "0") != "0" ?
        ((x,u) -> sparse(1.0I, nx, nx)) : ((x,u) -> Matrix{Float64}(I, nx, nx))
    fu = function (x,u)
        J = spzeros(nx, nu)
        for b in 1:nx
            J[b, pbidx[b]] = -dt
        end
        J
    end
    zxx = (x,u,λ) -> zeros(nx, nx)
    zux = (x,u,λ) -> spzeros(nu, nx)
    zuu = (x,u,λ) -> spzeros(nu, nu)
    DDP4OPF.Dynamics{nx,nu,typeof(f),typeof(fx),typeof(fu),typeof(zxx),typeof(zux),typeof(zuu)}(
        f, fx, fu, zxx, zux, zuu)
end

function analytic_objective(nx, nu, psidx, pbidx, price, pbase, dt, C_B)
    l = (x,u) -> [price*pbase*dt*u[psidx] + C_B*pbase^2*dt*sum(abs2, u[pbidx])]
    lx = (x,u) -> zeros(nx)
    lu = function (x,u)
        g = zeros(nu)
        g[psidx] = price*pbase*dt
        g[pbidx] .= 2C_B*pbase^2*dt .* u[pbidx]
        g
    end
    lxx = (x,u) -> zeros(nx, nx)
    lux = (x,u) -> spzeros(nu, nx)
    luu = function (x,u)
        H = spzeros(nu, nu)
        for k in pbidx
            H[k,k] = 2C_B*pbase^2*dt
        end
        H
    end
    DDP4OPF.Objective{nx,nu,typeof(l),typeof(lx),typeof(lu),typeof(lxx),typeof(lux),typeof(luu)}(
        l, lx, lu, lxx, lux, luu)
end

# Stage-T cost plus the soft terminal SOC penalty gamma * sum_b (B_b^T - B0_b)^2.
# FilterDDP evaluates its terminal objective at the last stage's (x, u) -- there
# is no state after it -- so the energy left at the end of the horizon is
# B^T = x - dt*u[pb], which couples x and u (lux != 0 on this one stage).
function soft_terminal_objective(base, nx, nu, pbidx, dt, B0, gamma)
    r(x,u) = x .- dt .* u[pbidx] .- B0
    l = (x,u) -> base.l(x,u) .+ gamma*sum(abs2, r(x,u))
    lx = (x,u) -> base.lx(x,u) .+ 2gamma .* r(x,u)
    lu = function (x,u)
        g = base.lu(x,u)
        g[pbidx] .-= 2gamma*dt .* r(x,u)
        g
    end
    lxx = (x,u) -> base.lxx(x,u) .+ 2gamma .* Matrix{Float64}(I, nx, nx)
    lux = function (x,u)
        H = sparse(base.lux(x,u))
        for b in 1:nx
            H[pbidx[b], b] -= 2gamma*dt
        end
        H
    end
    luu = function (x,u)
        H = sparse(base.luu(x,u))
        for k in pbidx
            H[k,k] += 2gamma*dt^2
        end
        H
    end
    DDP4OPF.Objective{nx,nu,typeof(l),typeof(lx),typeof(lu),typeof(lxx),typeof(lux),typeof(luu)}(
        l, lx, lu, lxx, lux, luu)
end

# Type-stable stage residuals for FILTERDDP_TYPED_EQUATIONS=1. `equations` in
# build_model pushes every residual into a Vector{Any} through Dict lookups:
# ~0.1 s per call at large10k, and FilterDDP calls it for every stage of every
# backward pass and every line-search rollout. This version resolves the
# indices and constants once and then performs the SAME floating-point
# operations in the SAME order (left-to-right sums, zero terms included), so
# its output is bitwise identical -- checked by check_typed_equations.jl.
function typed_equations(data, idx, t, qmax, buspos, linepos, batpos, derpos)
    buses, lines = data[:Nset], data[:Lset]
    batteries, ders = data[:Bset], data[:Dset]
    nonroot, root = data[:Nm1set], data[:substationBus]
    dt = data[:delta_t_h]
    nx = length(batteries)
    ps, qs = idx.ps, idx.qs
    rootP = Int[idx.P[linepos[e]] for e in data[:L1set]]
    rootQ = Int[idx.Q[linepos[e]] for e in data[:L1set]]
    nn = length(nonroot)
    inP = zeros(Int, nn); inQ = zeros(Int, nn); inell = zeros(Int, nn)
    rin = zeros(nn); xin = zeros(nn)
    childptr = ones(Int, nn + 1); childP = Int[]; childQ = Int[]
    pbi = zeros(Int, nn); qni = zeros(Int, nn); qmaxv = zeros(nn)
    pLv = zeros(nn); qLv = zeros(nn); pDv = zeros(nn)
    for (k, j) in enumerate(nonroot)
        line = (data[:parent][j], j)
        inP[k], inQ[k], inell[k] = idx.P[linepos[line]], idx.Q[linepos[line]], idx.ell[linepos[line]]
        rin[k], xin[k] = data[:rdict_pu][line], data[:xdict_pu][line]
        for ch in data[:children][j]
            push!(childP, idx.P[linepos[(j,ch)]]); push!(childQ, idx.Q[linepos[(j,ch)]])
        end
        childptr[k+1] = length(childP) + 1
        pLv[k] = j in data[:NLset] ? data[:p_L_pu][j,t] : 0.0
        qLv[k] = j in data[:NLset] ? data[:q_L_pu][j,t] : 0.0
        pDv[k] = j in ders ? data[:p_D_pu][j,t] : 0.0
        j in batteries && (pbi[k] = idx.pb[batpos[j]])
        j in ders && (qni[k] = idx.qnorm[derpos[j]]; qmaxv[k] = qmax[j])
    end
    nl = length(lines)
    lvi = zeros(Int, nl); lvj = zeros(Int, nl); lr = zeros(nl); lz = zeros(nl); lrz2 = zeros(nl)
    for (e, (i, j)) in enumerate(lines)
        lvi[e], lvj[e] = idx.v[buspos[i]], idx.v[buspos[j]]
        r, z = data[:rdict_pu][(i,j)], data[:xdict_pu][(i,j)]
        lr[e], lz[e], lrz2[e] = r, z, r^2 + z^2
    end
    vroot = idx.v[buspos[root]]
    vref = 1.05^2
    emin = Float64[data[:soc_min][j] * data[:B_R_pu][j] for j in batteries]
    P, Q, ell, soc, pb, es = idx.P, idx.Q, idx.ell, idx.soc_slack, idx.pb, idx.energy_slack
    nc = 2length(buses) + 2nl + 1 + nx
    return function (x, u)
        c = Vector{Float64}(undef, nc)
        @inbounds begin
            row = 1
            s = u[rootP[1]]
            for m in 2:length(rootP); s += u[rootP[m]]; end
            c[row] = u[ps] - s
            for k in 1:nn
                o = 0.0
                for m in childptr[k]:childptr[k+1]-1; o += u[childP[m]]; end
                pbval = pbi[k] == 0 ? 0.0 : u[pbi[k]]
                row += 1
                c[row] = o - u[inP[k]] + rin[k]*u[inell[k]] - pbval - pDv[k] + pLv[k]
            end
            row += 1
            s = u[rootQ[1]]
            for m in 2:length(rootQ); s += u[rootQ[m]]; end
            c[row] = u[qs] - s
            for k in 1:nn
                o = 0.0
                for m in childptr[k]:childptr[k+1]-1; o += u[childQ[m]]; end
                qD = qni[k] == 0 ? 0.0 : qmaxv[k]*u[qni[k]]
                row += 1
                c[row] = o - u[inQ[k]] + xin[k]*u[inell[k]] - qD + qLv[k]
            end
            for e in 1:nl
                row += 1
                c[row] = u[lvj[e]] - u[lvi[e]] + 2*(lr[e]*u[P[e]] + lz[e]*u[Q[e]]) - lrz2[e]*u[ell[e]]
            end
            for e in 1:nl
                row += 1
                c[row] = u[P[e]]^2 + u[Q[e]]^2 - u[lvi[e]]*u[ell[e]] + u[soc[e]]
            end
            row += 1
            c[row] = u[vroot] - vref
            for b in 1:nx
                row += 1
                c[row] = x[b] - dt*u[pb[b]] - emin[b] - u[es[b]]
            end
        end
        c
    end
end

function build_model(data; gamma=0.0, stages=nothing)
    Nstage = data[:T]
    buses, lines = data[:Nset], data[:Lset]
    batteries, ders = data[:Bset], data[:Dset]
    root = data[:substationBus]
    nonroot = data[:Nm1set]
    idx, nu = control_layout(data)
    nx = length(batteries)

    buspos = Dict(j => k for (k,j) in enumerate(buses))
    linepos = Dict(e => k for (k,e) in enumerate(lines))
    batpos = Dict(j => k for (k,j) in enumerate(batteries))
    derpos = Dict(j => k for (k,j) in enumerate(ders))

    dt = data[:delta_t_h]
    pbase = data[:kVA_B]
    dyn = analytic_dynamics(nx, nu, idx.pb, dt)

    lower = fill(-Inf, nu); upper = fill(Inf, nu)
    lower[idx.ps] = 0.0
    for (k,j) in enumerate(buses)
        lower[idx.v[k]] = data[:Vminpu][j]^2
        upper[idx.v[k]] = data[:Vmaxpu][j]^2
    end
    lower[idx.ell] .= 0.0
    for (k,j) in enumerate(batteries)
        lower[idx.pb[k]] = -data[:P_B_R_pu][j]
        upper[idx.pb[k]] =  data[:P_B_R_pu][j]
        width = (data[:soc_max][j] - data[:soc_min][j]) * data[:B_R_pu][j]
        lower[idx.energy_slack[k]] = 0.0
        upper[idx.energy_slack[k]] = width
    end
    lower[idx.qnorm] .= -1.0; upper[idx.qnorm] .= 1.0
    lower[idx.soc_slack] .= 0.0
    # Bound screening (voltage_screening.jl, spar_ddp/notes/CONSTRAINT_SCREENING.md).
    # FILTERDDP_SCREEN is a comma-separated list of exact reductions:
    #   substation  no limits on the substation voltage: it is fixed by its own
    #               equality row, at exactly its upper limit;
    #   vupper      no upper voltage limit where the rules prove it cannot bind
    #               in any period (limits here are per control, not per period);
    #   vlower      likewise for lower voltage limits;
    #   ell         no ell >= 0: implied by the SOC row, P^2 + Q^2 + s = v ell
    #               with s >= 0 and v > 0;
    #   psubs       no P_Subs >= 0 when the load exceeds everything the
    #               batteries and DERs can inject, in every period.
    # `all` selects every item.
    screen_items = ["substation", "vupper", "vlower", "ell", "psubs"]
    screen = Set(String.(strip.(split(get(ENV, "FILTERDDP_SCREEN", ""), ','; keepempty=false))))
    "all" in screen && (screen = Set(screen_items))
    isempty(setdiff(screen, screen_items)) || error("FILTERDDP_SCREEN: unknown item in $(collect(screen))")
    if !isempty(screen)
        vs = voltage_screen(data, Nstage)
        rk = buspos[root]
        drop_lo = 0; drop_up = 0
        for k in eachindex(buses)
            fixed = k == rk && "substation" in screen
            if fixed || (k != rk && "vlower" in screen && !any(@view vs.keep_lo[k, :]))
                lower[idx.v[k]] = -Inf; drop_lo += 1
            end
            if fixed || (k != rk && "vupper" in screen && !any(@view vs.keep_up[k, :]))
                upper[idx.v[k]] = Inf; drop_up += 1
            end
        end
        drop_ell = "ell" in screen
        drop_ell && (lower[idx.ell] .= -Inf)
        drop_ps = "psubs" in screen && minimum(vs.psubs_min) > 0
        drop_ps && (lower[idx.ps] = -Inf)
        @printf("BOUND_SCREEN %s: voltage limits dropped %d lower, %d upper of %d buses; ell >= 0 dropped on %d lines; P_Subs >= 0 dropped: %s (lossless lower bound %.3f p.u.)\n",
                join(sort!(collect(screen)), ","), drop_lo, drop_up, length(buses),
                drop_ell ? length(lines) : 0, drop_ps, minimum(vs.psubs_min))
    end
    limits = ControlLimits(lower, upper)

    # `stages`: build only these periods, for a process that owns some of them
    # (procs_pass.jl). The other entries get the first built period's objects, so
    # the lists keep their length; that process never evaluates them.
    stage_objs = Vector{Any}(undef, Nstage)
    stage_cons = Vector{Any}(undef, Nstage)
    built = isnothing(stages) ? (1:Nstage) : sort(collect(stages))
    for t in built
        price = data[:LoadShapeCost][t]
        stage_objs[t] = analytic_objective(nx, nu, idx.ps, idx.pb,
            price, pbase, dt, data[:C_B])

        qmax = Dict(j => sqrt(max(0.0, data[:S_D_R][j]^2 - data[:p_D_pu][j,t]^2)) for j in ders)
        function untyped_equations(x,u)
            c = Any[]
            # Real-power balance: root, then every non-root bus.
            push!(c, u[idx.ps] - sum(u[idx.P[linepos[e]]] for e in data[:L1set]))
            for j in nonroot
                incoming = u[idx.P[linepos[(data[:parent][j],j)]]]
                outgoing = sum(u[idx.P[linepos[(j,k)]]] for k in data[:children][j]; init=0.0)
                pL = j in data[:NLset] ? data[:p_L_pu][j,t] : 0.0
                pD = j in ders ? data[:p_D_pu][j,t] : 0.0
                pb = j in batteries ? u[idx.pb[batpos[j]]] : 0.0
                incoming_line = (data[:parent][j],j)
                r = data[:rdict_pu][incoming_line]
                push!(c, outgoing - incoming + r*u[idx.ell[linepos[incoming_line]]] - pb - pD + pL)
            end
            # Reactive-power balance.
            push!(c, u[idx.qs] - sum(u[idx.Q[linepos[e]]] for e in data[:L1set]))
            for j in nonroot
                incoming = u[idx.Q[linepos[(data[:parent][j],j)]]]
                outgoing = sum(u[idx.Q[linepos[(j,k)]]] for k in data[:children][j]; init=0.0)
                qL = j in data[:NLset] ? data[:q_L_pu][j,t] : 0.0
                qD = j in ders ? qmax[j]*u[idx.qnorm[derpos[j]]] : 0.0
                incoming_line = (data[:parent][j],j)
                z = data[:xdict_pu][incoming_line]
                push!(c, outgoing - incoming + z*u[idx.ell[linepos[incoming_line]]] - qD + qL)
            end
            # BFM voltage drop.
            for (e,(i,j)) in enumerate(lines)
                r, z = data[:rdict_pu][(i,j)], data[:xdict_pu][(i,j)]
                push!(c, u[idx.v[buspos[j]]] - u[idx.v[buspos[i]]] +
                         2*(r*u[idx.P[e]] + z*u[idx.Q[e]]) - (r^2+z^2)*u[idx.ell[e]])
            end
            # SOCP inequality P^2+Q^2 <= v_i*ell, with nonnegative slack.
            for (e,(i,_)) in enumerate(lines)
                push!(c, u[idx.P[e]]^2 + u[idx.Q[e]]^2 -
                         u[idx.v[buspos[i]]]*u[idx.ell[e]] + u[idx.soc_slack[e]])
            end
            push!(c, u[idx.v[buspos[root]]] - 1.05^2)
            # Bound the post-action energy x - dt*P_B with a box slack.
            for (b,j) in enumerate(batteries)
                emin = data[:soc_min][j] * data[:B_R_pu][j]
                push!(c, x[b] - dt*u[idx.pb[b]] - emin - u[idx.energy_slack[b]])
            end
            c
        end
        equations = get(ENV, "FILTERDDP_TYPED_EQUATIONS", "0") != "0" ?
            typed_equations(data, idx, t, qmax, buspos, linepos, batpos, derpos) :
            untyped_equations
        nc = 2length(buses) + 2length(lines) + 1 + nx
        cx = function (x,u)
            J = spzeros(nc, nx)
            first_energy = 2length(buses) + 2length(lines) + 2
            for b in 1:nx
                J[first_energy+b-1, b] = 1.0
            end
            J
        end
        # The constraint Jacobian has a fixed sparsity pattern. Build its
        # constant entries once per stage and update only the four
        # iterate-dependent SOC entries per line on each callback.
        cu_J = spzeros(nc, nu)
        let J = cu_J
            row = 1
            J[row, idx.ps] = 1.0
            for e in data[:L1set]
                J[row, idx.P[linepos[e]]] -= 1.0
            end
            for j in nonroot
                row += 1
                incoming_line = (data[:parent][j],j)
                J[row, idx.P[linepos[incoming_line]]] -= 1.0
                J[row, idx.ell[linepos[incoming_line]]] += data[:rdict_pu][incoming_line]
                for k in data[:children][j]
                    J[row, idx.P[linepos[(j,k)]]] += 1.0
                end
                j in batteries && (J[row, idx.pb[batpos[j]]] -= 1.0)
            end
            row += 1
            J[row, idx.qs] = 1.0
            for e in data[:L1set]
                J[row, idx.Q[linepos[e]]] -= 1.0
            end
            for j in nonroot
                row += 1
                incoming_line = (data[:parent][j],j)
                J[row, idx.Q[linepos[incoming_line]]] -= 1.0
                J[row, idx.ell[linepos[incoming_line]]] += data[:xdict_pu][incoming_line]
                for k in data[:children][j]
                    J[row, idx.Q[linepos[(j,k)]]] += 1.0
                end
                j in ders && (J[row, idx.qnorm[derpos[j]]] -= qmax[j])
            end
            for (e,(i,j)) in enumerate(lines)
                row += 1
                r, z = data[:rdict_pu][(i,j)], data[:xdict_pu][(i,j)]
                J[row, idx.v[buspos[j]]] = 1.0
                J[row, idx.v[buspos[i]]] = -1.0
                J[row, idx.P[e]] = 2r
                J[row, idx.Q[e]] = 2z
                J[row, idx.ell[e]] = -(r^2+z^2)
            end
            for (e,(i,_)) in enumerate(lines)
                row += 1
                # Nonzero placeholders retain these positions in the CSC
                # structure until the first value update.
                J[row, idx.P[e]] = 1.0
                J[row, idx.Q[e]] = 1.0
                J[row, idx.v[buspos[i]]] = 1.0
                J[row, idx.ell[e]] = 1.0
                J[row, idx.soc_slack[e]] = 1.0
            end
            row += 1
            J[row, idx.v[buspos[root]]] = 1.0
            for b in 1:nx
                row += 1
                J[row, idx.pb[b]] = -dt
                J[row, idx.energy_slack[b]] = -1.0
            end
        end
        cu = let J = cu_J
            function (x,u)
                row = 2length(buses) + length(lines)
                for (e,(i,_)) in enumerate(lines)
                    row += 1
                    J[row, idx.P[e]] = 2u[idx.P[e]]
                    J[row, idx.Q[e]] = 2u[idx.Q[e]]
                    J[row, idx.v[buspos[i]]] = -u[idx.ell[e]]
                    J[row, idx.ell[e]] = -u[idx.v[buspos[i]]]
                end
                J
            end
        end
        cxx = (x,u,ϕ) -> zeros(nx, nx)
        cux = (x,u,ϕ) -> spzeros(nu, nx)
        cuu = if get(ENV, "FILTERDDP_TRIPLET_SECOND_DERIVATIVES", "0") != "0"
            # The SOCP Hessian pattern is fixed.  Assemble its four entries per
            # branch in one sparse constructor instead of repeatedly inserting
            # into a CSC matrix.
            I = Vector{Int}(undef, 4length(lines))
            J = similar(I)
            for (e,(i,_)) in enumerate(lines)
                p, q = idx.P[e], idx.Q[e]
                v, ell = idx.v[buspos[i]], idx.ell[e]
                k = 4(e - 1)
                I[k+1], J[k+1] = p, p
                I[k+2], J[k+2] = q, q
                I[k+3], J[k+3] = v, ell
                I[k+4], J[k+4] = ell, v
            end
            first_soc = 2length(buses) + length(lines) + 1
            let I=I, J=J, first_soc=first_soc
                function (x,u,ϕ)
                    V = Vector{eltype(ϕ)}(undef, length(I))
                    @inbounds for e in eachindex(lines)
                        weight = ϕ[first_soc+e-1]
                        k = 4(e - 1)
                        V[k+1] = 2weight
                        V[k+2] = 2weight
                        V[k+3] = -weight
                        V[k+4] = -weight
                    end
                    sparse(I, J, V, nu, nu)
                end
            end
        else
            function (x,u,ϕ)
                H = spzeros(nu, nu)
                first_soc = 2length(buses) + length(lines) + 1
                for (e,(i,_)) in enumerate(lines)
                    weight = ϕ[first_soc+e-1]
                    p, q = idx.P[e], idx.Q[e]
                    v, ell = idx.v[buspos[i]], idx.ell[e]
                    H[p,p] += 2weight
                    H[q,q] += 2weight
                    H[v,ell] -= weight
                    H[ell,v] -= weight
                end
                H
            end
        end
        con = DDP4OPF.EqualityConstraints{nx,nu,nc,typeof(equations),typeof(cx),typeof(cu),typeof(cxx),typeof(cux),typeof(cuu)}(
            equations, cx, cu, cxx, cux, cuu)
        stage_cons[t] = con
    end
    for t in 1:Nstage
        isassigned(stage_objs, t) && continue
        stage_objs[t] = stage_objs[first(built)]
        stage_cons[t] = stage_cons[first(built)]
    end

    # FilterDDP has a control at its final stage; use that stage's ordinary cost,
    # plus the soft terminal SOC penalty when gamma > 0 (terminal_soc_penalty.jl).
    term = gamma > 0 ?
        soft_terminal_objective(stage_objs[end], nx, nu, idx.pb, dt,
            Float64[data[:B0_pu][j] for j in batteries], gamma) :
        stage_objs[end]
    ocp = build_ocp(Nstage, stage_objs[1], term, dyn, stage_cons[1], limits;
                    stage_objectives=stage_objs, stage_constraints=stage_cons)
    return ocp, idx, nx, nu, length(stage_cons[1].c(zeros(nx), zeros(nu)))
end

# Largest violation of a stage's constraints as posed, for FILTERDDP_ORIGINAL_PRIMAL
# lines (DDP4OPF.PRIMAL_ORIGINAL_HOOK): the cone row P^2 + Q^2 - v ell + s = 0 counts
# only by how far P^2 + Q^2 exceeds v ell, and the energy row only by how far the
# energy after the stage is outside its window; the balances, the voltage drops and
# the substation voltage count as they are. Rows as in `equations` of build_model.
function install_original_primal_hook(data, idx)
    N, L, bats = length(data[:Nset]), length(data[:Lset]), data[:Bset]
    width = [(data[:soc_max][j] - data[:soc_min][j]) * data[:B_R_pu][j] for j in bats]
    audit_screened = get(ENV, "FILTERDDP_SCREEN_ABLATION_ORIGINAL_BOUNDS", "0") == "1"
    audit_screened && println("SCREEN_ABLATION_ORIGINAL_BOUNDS enabled")
    DDP4OPF.PRIMAL_ORIGINAL_HOOK[] = function (t, x, u, c)
        v = 0.0
        @inbounds for i in 1:2N+L; v = max(v, abs(c[i])); end
        @inbounds for e in 1:L; v = max(v, c[2N+L+e] - u[idx.soc_slack[e]]); end
        v = max(v, abs(c[2N+2L+1]))
        @inbounds for b in eachindex(bats)
            w = c[2N+2L+1+b] + u[idx.energy_slack[b]]
            v = max(v, -w, w - width[b])
        end
        if audit_screened
            @inbounds for (k, j) in enumerate(data[:Nset])
                v = max(v, data[:Vminpu][j]^2 - u[idx.v[k]],
                        u[idx.v[k]] - data[:Vmaxpu][j]^2)
            end
            @inbounds for e in idx.ell; v = max(v, -u[e]); end
            v = max(v, -u[idx.ps])
        end
        return v
    end
    return nothing
end

function main(args=ARGS)
system = length(args) >= 1 ? args[1] : "ieee123C_1ph"
T = length(args) >= 2 ? parse(Int, args[2]) : 2
mode = length(args) >= 3 ? args[3] : "dimensions"
quiet = length(args) >= 4 && args[4] == "quiet"
ptag = haskey(ENV, "REDUCED_PROFILE") ? "_" * ENV["REDUCED_PROFILE"] : ""
datafile = joinpath(REPO, "spar_ddp", "results", "network_filterddp",
                    "network_data_$(system)_T$(T)$(ptag).jls")
data = deserialize(datafile)
# Opt-in C_B override so the full-space reference can be regenerated at the same
# battery cost as a reduced-space experiment. Default behaviour is unchanged.
if haskey(ENV, "REDUCED_CB")
    data[:C_B] = battery_cb(system, ENV["REDUCED_CB"])   # a number, or "system"
    @printf("C_B OVERRIDE: %.6g\n", data[:C_B])
end
idx, nu = control_layout(data)
nx = length(data[:Bset])
nc = 2length(data[:Nset]) + 2length(data[:Lset]) + 1 + nx

@printf("%s T=%d: nx=%d, nu=%d, nc=%d, dense nu^2=%d, reduced=%d\n",
        system, T, nx, nu, nc, nu^2, nu-nc)
mode == "dimensions" && exit()

t0 = time()
gammaT = terminal_soc_soft() ? gamma_terminal(system) : 0.0
@printf("TERMINAL_SOC soft=%d gamma=%.6e\n", gammaT > 0, gammaT)
ocp, idx, nx, nu, nc_actual = build_model(data; gamma=gammaT)
@printf("build complete: %.3f s, nc=%d\n", time()-t0, nc_actual)
get(ENV, "FILTERDDP_TREE_KKT", "0") != "0" && install_tree_kkt_hook(data, idx, nu)
get(ENV, "FILTERDDP_PINT_SCAN", "0") != "0" && install_pint_scan_hook()
get(ENV, "FILTERDDP_THREADED", "0") != "0" && install_threaded_pass(data, idx)
get(ENV, "FILTERDDP_FEASIBILITY_DIAGNOSTIC", "0") == "1" && install_original_primal_hook(data, idx)
mode == "build" && exit()

println("constructing dynamic Solver storage...")
flush(stdout)
t_solver = time()
max_iterations = parse(Int, get(ENV, "FILTERDDP_MAX_ITERATIONS", "200"))
optimality_tolerance = parse(Float64, get(ENV, "FILTERDDP_OPTIMALITY_TOLERANCE", "1e-7"))
# Barrier schedule (run_barrier_sweep.sh): mu starts at FILTERDDP_MU_INIT and,
# once the barrier problem is solved to FILTERDDP_KAPPA_EPS * mu, becomes
# max(tol / 10, min(FILTERDDP_KAPPA_MU * mu, mu ^ FILTERDDP_THETA_MU)).
barrier_options = Dict{Symbol, Float64}()
for (name, key) in (("FILTERDDP_MU_INIT", :μ_init), ("FILTERDDP_KAPPA_MU", :κ_μ),
                    ("FILTERDDP_THETA_MU", :θ_μ), ("FILTERDDP_KAPPA_EPS", :κ_ϵ))
    haskey(ENV, name) && (barrier_options[key] = parse(Float64, ENV[name]))
end
solver = Solver(ocp; options=Options{Float64}(; verbose=!quiet,
    optimality_tolerance=optimality_tolerance, max_iterations=max_iterations, barrier_options...))
@printf("optimality_tolerance=%.3e max_iterations=%d\n", optimality_tolerance, max_iterations)
@printf("BARRIER_OPTIONS mu_init=%g kappa_mu=%g theta_mu=%g kappa_eps=%g\n", solver.options.μ_init,
        solver.options.κ_μ, solver.options.θ_μ, solver.options.κ_ϵ)
@printf("Solver construction complete: %.3f s\n", time()-t_solver)
mode == "solver" && exit()
x0 = Float64[data[:B0_pu][j] for j in data[:Bset]]
u0 = zeros(nu)
u0[idx.ps] = 1.0
u0[idx.v] .= 1.0
u0[idx.ell] .= 1e-3
u0[idx.soc_slack] .= 1e-3
for (b,j) in enumerate(data[:Bset])
    emin = data[:soc_min][j] * data[:B_R_pu][j]
    u0[idx.energy_slack[b]] = x0[b] - emin
end
ubar = [copy(u0) for _ in 1:T]
if get(ENV, "FILTERDDP_LOADFLOW_START", "0") != "0"
    init_start_ns = time_ns()
    sweeps = maximum(loadflow_start!(ubar[t], data, idx, t) for t in 1:T)
    res0 = maximum(norm(ocp.stage_constraints[t].c(x0, ubar[t]), Inf) for t in 1:T)
    @printf("LOADFLOW_START sweeps=%d max_equality_residual=%.3e lowest_voltage=%.4f pu\n",
            sweeps, res0, sqrt(minimum(minimum(@view ubar[t][idx.v]) for t in 1:T)))
    @printf("FILTERDDP_START_TIMING powerflow_init_s=%.9f initialization_first_call=1\n", (time_ns()-init_start_ns)/1e9)
end
# FILTERDDP_WARMUP=<n> or `full`: run the same solve first, silently, for n
# iterations or to its normal stop, and discard it. Julia compiles each method
# the first time it runs (15-30 s here, nearly all inside the first iteration),
# so without this the timed solve below includes that one-time cost. `full`
# reaches every code path (barrier updates, the stopping test); a small n is
# for long horizons, where a second complete solve is too expensive. The timed
# solve restarts from the same point and reproduces the same iterates.
ctx=SHA.SHA2_256_CTX()
for u in ubar; SHA.update!(ctx,reinterpret(UInt8,u)); end
println("FULL_STUDY_START x0_sha256=$(bytes2hex(sha256(reinterpret(UInt8,x0)))) ubar_sha256=$(bytes2hex(SHA.digest!(ctx)))")
warmup_spec = get(ENV, "FILTERDDP_WARMUP", "0")
warmup = warmup_spec == "full" ? typemax(Int) : parse(Int, warmup_spec)
if warmup > 0
    keep_max = solver.options.max_iterations
    solver.options.max_iterations = min(warmup, keep_max)
    tw = time()
    # To a scratch file, not devnull: the print methods are compiled per stream
    # type, and the log is a file. With devnull about 1.7 s of compilation was
    # left in the timed solve.
    scratch = tempname()
    warm_stream = Ref{Any}(nothing)
    open(scratch, "w") do io
        redirect_stdout(io) do
            warm_stream[] = typeof(stdout)
            solve!(solver, x0, [copy(u) for u in ubar])
        end
    end
    rm(scratch; force=true)
    solver.options.max_iterations = keep_max
    @printf("WARMUP %s iterations=%d time_s=%.3f\n", warmup_spec, solver.data.k, time() - tw)
    # The warm-up only helps if the timed solve prints to the same stream type.
    # With NO_COLOR or FORCE_COLOR in the environment Julia wraps stdout in an
    # IOContext, and every print statement is compiled again in the first pass
    # of the timed solve (0.7 s, more with diagnostics): the run scripts unset both.
    warm_stream[] == typeof(stdout) || println("WARMUP_STREAM_MISMATCH warm-up printed to ", warm_stream[],
        ", the timed solve prints to ", typeof(stdout), ": its first pass includes print compilation")
end
# The warm-up's garbage is not the timed solve's: collect it now, so that the
# first collection inside the timed solve does not pay for it (one pass of
# 0.38 s in a 0.3 s solve, ieee123 T=6 on 2026-10-11). The time the collector
# takes inside the timed solve is printed, for what it is worth at small sizes.
warmup > 0 && GC.gc()
gc_before = Base.gc_time_ns()
t1 = time()
println("entering solve! ...")
flush(stdout)
status = solve!(solver, x0, ubar)
@printf("solve complete: %.3f s, iterations=%d, status=%s\n",
        time()-t1, solver.data.k, string(status))
@printf("FILTERDDP_GC_TIME gc_s=%.3f collected_before_solve=%d\n", (Base.gc_time_ns() - gc_before) / 1e9, warmup > 0)
# Peak resident memory of the whole process (build + solve), for the memory
# comparison with centralized Ipopt.
@printf("FILTERDDP_MEMORY_PEAK maxrss_mib=%.1f\n", Sys.maxrss() / 2^20)
@printf("final residuals: primal=%.12e dual=%.12e complementarity=%.12e\n",
        solver.data.primal_inf, solver.data.dual_inf, solver.data.cs_inf_0)

# Compare against the existing centralized JuMP/Ipopt result when available.
xddp, uddp = get_trajectory(solver)
if get(ENV, "FILTERDDP_SKIP_SOLUTION_WRITE", "0") != "1"
    # Tag the filename when C_B is overridden: the stored references are at the
    # exported C_B and must not be silently replaced by a different problem.
    cbtag = haskey(ENV, "REDUCED_CB") ? "_CB$(ENV["REDUCED_CB"])" : ""
    solutionfile = joinpath(REPO, "spar_ddp", "results", "network_filterddp",
                            "filterddp_solution_$(system)_T$(T)$(ptag)$(cbtag).jls")
    serialize(solutionfile, Dict(
        :system => system,
        :T => T,
        :status => status,
        :iterations => solver.data.k,
        :x => xddp,
        :u => uddp,
    ))
    println("saved_solution=$solutionfile")
else
    println("solution_write_skipped=1")
end
flush(stdout)
Jddp = 0.0
max_eq = 0.0
for t in 1:T
    Jddp += data[:LoadShapeCost][t]*data[:kVA_B]*data[:delta_t_h]*uddp[t][idx.ps]
    Jddp += data[:C_B]*data[:kVA_B]^2*data[:delta_t_h]*sum(uddp[t][k]^2 for k in idx.pb)
    max_eq = max(max_eq, norm(ocp.stage_constraints[t].c(xddp[t], uddp[t]), Inf))
end
if gammaT > 0
    for (b,j) in enumerate(data[:Bset])
        BT = xddp[T][b] - data[:delta_t_h]*uddp[T][idx.pb[b]]
        Jddp += gammaT*(BT - data[:B0_pu][j])^2
    end
end
@printf("FilterDDP objective=%.12f max_equality_residual=%.3e\n", Jddp, max_eq)
# Every screened quantity against its ORIGINAL limits, whether or not the limit
# was in the solve (FILTERDDP_SCREEN): the after-the-fact certificate that a
# dropped limit did not matter.
let below = 0, above = 0, worst = 0.0, ellmin = Inf, psmin = Inf
    for t in 1:T
        for (k,j) in enumerate(data[:Nset])
            lo = data[:Vminpu][j]^2 - uddp[t][idx.v[k]]; hi = uddp[t][idx.v[k]] - data[:Vmaxpu][j]^2
            lo > 1e-8 && (below += 1); hi > 1e-8 && (above += 1)
            worst = max(worst, lo, hi)
        end
        ellmin = min(ellmin, minimum(@view uddp[t][idx.ell])); psmin = min(psmin, uddp[t][idx.ps])
    end
    @printf("BOUND_CHECK screen=%s voltages below=%d above=%d worst_violation=%.3e min_ell=%.3e min_P_Subs=%.3e\n",
            get(ENV, "FILTERDDP_SCREEN", "none"), below, above, worst, ellmin, psmin)
end

reffile = joinpath(REPO, "envs", "tadmm", "processedData", "$(system)_T$(T)", "sol_socp_bf.jls")
if isfile(reffile)
    ref = deserialize(reffile)
    maxdiff = Dict(:P_Subs=>0.0, :Q_Subs=>0.0, :P=>0.0, :Q=>0.0,
                   :v=>0.0, :ell=>0.0, :P_B=>0.0, :B=>0.0, :q_D=>0.0)
    for t in 1:T
        maxdiff[:P_Subs] = max(maxdiff[:P_Subs], abs(uddp[t][idx.ps] - ref[:P_Subs][t]))
        maxdiff[:Q_Subs] = max(maxdiff[:Q_Subs], abs(uddp[t][idx.qs] - ref[:Q_Subs][t]))
        for (e,line) in enumerate(data[:Lset])
            maxdiff[:P] = max(maxdiff[:P], abs(uddp[t][idx.P[e]] - ref[:P][line,t]))
            maxdiff[:Q] = max(maxdiff[:Q], abs(uddp[t][idx.Q[e]] - ref[:Q][line,t]))
            maxdiff[:ell] = max(maxdiff[:ell], abs(uddp[t][idx.ell[e]] - ref[:ℓ][line,t]))
        end
        for (k,j) in enumerate(data[:Nset])
            maxdiff[:v] = max(maxdiff[:v], abs(uddp[t][idx.v[k]] - ref[:v][j,t]))
        end
        for (b,j) in enumerate(data[:Bset])
            maxdiff[:P_B] = max(maxdiff[:P_B], abs(uddp[t][idx.pb[b]] - ref[:P_B][j,t]))
            Bpost = xddp[t][b] - data[:delta_t_h]*uddp[t][idx.pb[b]]
            maxdiff[:B] = max(maxdiff[:B], abs(Bpost - ref[:B][j,t]))
        end
        for (d,j) in enumerate(data[:Dset])
            qmax = sqrt(max(0.0, data[:S_D_R][j]^2 - data[:p_D_pu][j,t]^2))
            maxdiff[:q_D] = max(maxdiff[:q_D], abs(qmax*uddp[t][idx.qnorm[d]] - ref[:q_D][j,t]))
        end
    end
    @printf("Ipopt objective=%.12f objective_gap=%.3e\n", ref[:objective], abs(Jddp-ref[:objective]))
    for key in (:P_Subs,:Q_Subs,:P,:Q,:v,:ell,:P_B,:B,:q_D)
        @printf("max_abs_diff[%s]=%.3e\n", string(key), maxdiff[key])
    end
end
end

if abspath(PROGRAM_FILE) == abspath(@__FILE__)
    main()
end
