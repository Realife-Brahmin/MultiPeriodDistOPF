const MERGE_OPERATIONS = "assemble_matrix,assemble_vector,cholesky,transpose,copy,solve_vector,solve_matrix,syrk,mirror,gemm,gemv,fallback"
function profile_combine!(x::PintElem, y::PintElem, w::PairWork, ticks)
    K = w.K; g = w.g
    stamp = time_ns()
    K .= x.Mbb .+ y.Maa
    ticks[1] += time_ns() - stamp
    stamp = time_ns()
    g .= x.mb .+ y.ma
    ticks[2] += time_ns() - stamp
    stamp = time_ns()
    C = cholesky!(Symmetric(K); check=false)
    ticks[3] += time_ns() - stamp
    if !issuccess(C)
        stamp = time_ns()
        r = pint_combine(x, y)
        copyto!(x.Maa, r.Maa); copyto!(x.Mab, r.Mab); copyto!(x.Mbb, r.Mbb); copyto!(x.ma, r.ma); copyto!(x.mb, r.mb)
        ticks[12] += time_ns() - stamp
        return x
    end
    U = C.U
    stamp = time_ns()
    transpose!(w.Y1, x.Mab)
    ticks[4] += time_ns() - stamp
    stamp = time_ns()
    ldiv!(U', w.Y1)
    ticks[7] += time_ns() - stamp
    stamp = time_ns()
    copyto!(w.Y2, y.Mab)
    ticks[5] += time_ns() - stamp
    stamp = time_ns()
    ldiv!(U', w.Y2)
    ticks[7] += time_ns() - stamp
    stamp = time_ns()
    ldiv!(U', g)
    ticks[6] += time_ns() - stamp
    stamp = time_ns()
    BLAS.syrk!('U', 'T', -1.0, w.Y1, 1.0, x.Maa)
    ticks[8] += time_ns() - stamp
    stamp = time_ns()
    LinearAlgebra.copytri!(x.Maa, 'U')
    ticks[9] += time_ns() - stamp
    stamp = time_ns()
    copyto!(x.Mbb, y.Mbb)
    ticks[5] += time_ns() - stamp
    stamp = time_ns()
    BLAS.syrk!('U', 'T', -1.0, w.Y2, 1.0, x.Mbb)
    ticks[8] += time_ns() - stamp
    stamp = time_ns()
    LinearAlgebra.copytri!(x.Mbb, 'U')
    ticks[9] += time_ns() - stamp
    stamp = time_ns()
    mul!(x.Mab, w.Y1', w.Y2, -1.0, 0.0)
    ticks[10] += time_ns() - stamp
    stamp = time_ns()
    mul!(x.ma, w.Y1', g, -1.0, 1.0)
    ticks[11] += time_ns() - stamp
    stamp = time_ns()
    copyto!(x.mb, y.mb)
    ticks[5] += time_ns() - stamp
    stamp = time_ns()
    mul!(x.mb, w.Y2', g, -1.0, 1.0)
    ticks[11] += time_ns() - stamp
    return x
end
function profile_combine!(x::PintElem, y::PintVal, w::PairWork, ticks)
    K = w.K; g = w.g
    stamp = time_ns()
    K .= x.Mbb .+ y.V
    ticks[1] += time_ns() - stamp
    stamp = time_ns()
    g .= x.mb .+ y.v
    ticks[2] += time_ns() - stamp
    stamp = time_ns()
    C = cholesky!(Symmetric(K); check=false)
    ticks[3] += time_ns() - stamp
    if !issuccess(C)
        stamp = time_ns()
        r = pint_combine(x, y)
        copyto!(x.Maa, r.V); copyto!(x.ma, r.v)
        ticks[12] += time_ns() - stamp
        return PintVal(x.Maa, x.ma)
    end
    U = C.U
    stamp = time_ns()
    transpose!(w.Y1, x.Mab)
    ticks[4] += time_ns() - stamp
    stamp = time_ns()
    ldiv!(U', w.Y1)
    ticks[7] += time_ns() - stamp
    stamp = time_ns()
    ldiv!(U', g)
    ticks[6] += time_ns() - stamp
    stamp = time_ns()
    BLAS.syrk!('U', 'T', -1.0, w.Y1, 1.0, x.Maa)
    ticks[8] += time_ns() - stamp
    stamp = time_ns()
    LinearAlgebra.copytri!(x.Maa, 'U')
    ticks[9] += time_ns() - stamp
    stamp = time_ns()
    mul!(x.ma, w.Y1', g, -1.0, 1.0)
    ticks[11] += time_ns() - stamp
    return PintVal(x.Maa, x.ma)
end
