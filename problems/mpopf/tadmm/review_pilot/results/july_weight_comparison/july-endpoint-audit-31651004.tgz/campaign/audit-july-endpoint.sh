#!/usr/bin/env bash
set -euo pipefail
C=/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_july_weights
REF=/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_accuracy_fix
cd "$C/source"
export PATH=/home/aryan.jha/opt/julia-1.12.4/bin:$PATH
export JULIA_DEPOT_PATH="$C/julia-depot:$REF/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_parallel/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_v2/julia-depot:/home/aryan.jha/kamiak_jobs/tree_ablation_oct20_campaign_v2/julia-depot"
export JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TADMM_LINEAR_SOLVER=ma57
export TADMM_IPOPT_OPTIONS="hsllib=$HOME/opt/hsl-private/install/ma57-3.11.3-metis/lib/libma57.so;linear_system_scaling=none;ma57_pivot_order=2"
sha256sum --check --quiet "$C/execution-source.sha256"
OUT="$C/endpoint-audit-$SLURM_JOB_ID"
mkdir -p "$OUT"
sha256sum "$C/campaign/audit_july_endpoint.jl" "$0" > "$OUT/analysis-source.sha256"
julia --startup-file=no --project=problems/mpopf/tadmm/review_pilot "$C/campaign/audit_july_endpoint.jl" "$C/source" "$C/results/large10kC_1ph_T24_july_pair_31650589" "$OUT"
