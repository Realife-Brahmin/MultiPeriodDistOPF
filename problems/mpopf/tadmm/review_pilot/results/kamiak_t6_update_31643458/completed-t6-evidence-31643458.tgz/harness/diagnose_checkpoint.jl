# Standalone checkpoint diagnostic; never used as a fresh benchmark trajectory.
using Serialization, SHA, TOML
source,case,out=ARGS
include(joinpath(source,"problems/mpopf/tadmm/review_pilot/model.jl"))
BLAS.set_num_threads(1)
isdir(out) && error("Refusing existing diagnostic output: $out")
mkpath(out)
checkpoint=joinpath(case,"warmup_checkpoint.jls")
cp(checkpoint,joinpath(out,"checkpoint.jls"))
state=deserialize(joinpath(out,"checkpoint.jls")); d=deserialize(joinpath(case,"instance.jls"))
bytes2hex(sha256(read(joinpath(source,"problems/mpopf/tadmm/review_pilot/model.jl"))))==state[:model_sha256] || error("Checkpoint source mismatch")
open(joinpath(out,"comparison.csv"),"w") do io
    println(io,"backend,scaling,period,checkpoint_iteration,rho,status,ipopt_iterations,objective,all_primal_difference_from_saved_max,local_constraint_violation_max")
    for backend in ("ma57","ma97"), scaling in ("gradient-based","none"), t in 1:d[:T]
        ENV["TADMM_LINEAR_SOLVER"]=backend
        lib=joinpath(homedir(),"opt/hsl-private/install",backend=="ma57" ? "ma57-3.11.3-metis/lib/libma57.so" : "hsl_ma97-2.8.1-metis-openmp/lib/libhsl_ma97.so")
        extra=backend=="ma57" ? "ma57_pivot_order=2" : "ma97_order=amd"
        ENV["TADMM_IPOPT_OPTIONS"]="hsllib=$lib;linear_system_scaling=none;$extra;nlp_scaling_method=$scaling"
        s=make_model(d,[t];local_window=true,rho=state[:rho])
        saved=state[:stage_primals][t]
        set_start_value.(s.vars,saved)
        set_optimizer_attribute(s.m,"print_level",5)
        set_optimizer_attribute(s.m,"output_file",joinpath(out,"$(backend)_$(scaling)_p$(t).log"))
        row=stage_step!(s,d,state[:z],state[:dual][t],state[:rho],1)
        # Compare all primal variables too; the checkpoint is a previous iteration,
        # so a difference is diagnostic evidence, not an exact-replay assertion.
        report=primal_feasibility_report(s.m;atol=0.0)
        viol=maximum(values(report);init=0.0)
        delta=maximum(abs.(value.(s.vars).-saved);init=0.0)
        println(io,join((backend,scaling,t,state[:iteration],state[:rho],row.status,row.iterations,objective_value(s.m),delta,viol),',')); flush(io)
        open(joinpath(out,"$(backend)_$(scaling)_p$(t).toml"),"w") do result
            TOML.print(result,Dict("copies"=>[collect(row.copy_b[:,i]) for i in axes(row.copy_b,2)],"times"=>s.times))
        end
        s=nothing; GC.gc()
    end
end
