#!/usr/bin/env bash
set -euo pipefail
C=$1; T=$2; J=$3; CASE="$C/results/run_T${T}_primal_dual_$J"
if [[ ! -s "$CASE/SWEEP_VALIDATED" ]]; then echo 'No validated endpoint; no completed audit claimed.'; exit 0; fi
export TADMM_AUDIT_LAYOUT="$C/source/problems/mpopf/spar_ddp/examples/power_system/control_layout.jl"
export TADMM_AUDIT_VALIDATED_ONLY=1 JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
/home/aryan.jha/opt/julia-1.12.4/bin/julia --startup-file=no "$C/campaign/audit_sweep_energy.jl" "$CASE" "$C/campaign/T$T-$J-energy.toml"
