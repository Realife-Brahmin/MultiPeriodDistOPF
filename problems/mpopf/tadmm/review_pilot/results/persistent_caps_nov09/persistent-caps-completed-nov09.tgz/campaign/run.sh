#!/usr/bin/env bash
set -euo pipefail
C=$1;CAP=$2;test -s "$C/PERSISTENT_CAP_GATE_VALIDATED"
export TADMM_RHO_POLICY=bootstrap_fixed TADMM_RHO_FLOOR=48 TADMM_LOCAL_SOLVE_POLICY=persistent_cap
export TADMM_CAP_ITERATIONS=$CAP TADMM_CAP_SCREEN=finite
exec bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" 24 run primal_dual 15000 ma57 large10kC_1ph
