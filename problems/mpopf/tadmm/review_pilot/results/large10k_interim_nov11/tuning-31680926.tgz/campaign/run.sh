#!/usr/bin/env bash
set -euo pipefail
C=$1
T=$2
CAP=$3
MODEL=$4
[[ ${SLURM_JOB_NUM_NODES:?} == 1 ]]
test -s "$C/INTERIM_PROFILES_VALIDATED"
CPU_INFO=$(lscpu)
grep -Fq "$MODEL" <<< "$CPU_INFO"
export TADMM_CPU_MODEL_MATCH=$MODEL
export TADMM_RHO_POLICY=bootstrap_fixed TADMM_BOOTSTRAP_DECREASE=5 TADMM_BOOTSTRAP_GATE=Inf TADMM_RHO_FLOOR=24
export TADMM_RHO_PROVENANCE="Transfer from fastest large10k T48 tuning configuration"
if [[ $CAP == exact ]]; then
 export TADMM_LOCAL_SOLVE_POLICY=exact
else
 export TADMM_LOCAL_SOLVE_POLICY=persistent_cap TADMM_CAP_ITERATIONS=$CAP TADMM_CAP_SCREEN=finite
fi
exec bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" "$T" run primal_dual 15000 ma57 large10kC_1ph
