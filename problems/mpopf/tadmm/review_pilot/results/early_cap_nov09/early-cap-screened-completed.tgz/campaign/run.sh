#!/usr/bin/env bash
set -euo pipefail
C=$1;test -s "$C/EARLY_CAP_GATE_VALIDATED"
export TADMM_RHO_POLICY=bootstrap_fixed TADMM_RHO_FLOOR=48 TADMM_LOCAL_SOLVE_POLICY=early_cap30
export TADMM_CAP_ITERATIONS=30 TADMM_CAP_END_ITERATION=30 TADMM_CAP_PRIMAL_TOL=1e-6
exec bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" 24 run primal_dual 15000 ma57 large10kC_1ph
