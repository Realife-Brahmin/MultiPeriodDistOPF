#!/usr/bin/env bash
set -euo pipefail
C=/home/aryan.jha/kamiak_jobs/tadmm_review_nov08_mumps_full_period
P=problems/mpopf/tadmm/review_pilot
cd "$C/source"
export JULIA_DEPOT_PATH="$C/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov08_horizon_sweep/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_accuracy_fix/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_v2/julia-depot:/home/aryan.jha/kamiak_jobs/tree_ablation_oct20_campaign_v2/julia-depot"
export JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export TADMM_LINEAR_SOLVER=mumps TADMM_IPOPT_OPTIONS=linear_system_scaling=none
/home/aryan.jha/opt/julia-1.12.4/bin/julia --startup-file=no --project="$P" "$P/validate_stage_reuse.jl"
date -u +%FT%TZ > "$C/MUMPS_UNIT_VALIDATED"
