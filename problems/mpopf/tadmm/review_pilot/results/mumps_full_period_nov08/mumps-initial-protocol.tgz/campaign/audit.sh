#!/usr/bin/env bash
set -euo pipefail
C=$1;J=$2;CASE="$C/results/run_T48_primal_dual_$J"
if [[ ! -s "$CASE/SWEEP_VALIDATED" ]];then
 printf '%s\n' 'Benchmark incomplete; no complete endpoint audit claimed.' > "$C/campaign/audit-$J-not-complete.txt"
 exit 0
fi
export TADMM_AUDIT_LAYOUT="$C/source/problems/mpopf/spar_ddp/examples/power_system/control_layout.jl"
export TADMM_AUDIT_VALIDATED_ONLY=1 JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
sha256sum "$C/campaign/audit_sweep_energy.jl" "$TADMM_AUDIT_LAYOUT" > "$C/campaign/audit-$J.sha256"
/home/aryan.jha/opt/julia-1.12.4/bin/julia --startup-file=no "$C/campaign/audit_sweep_energy.jl" "$CASE" "$C/campaign/T48-$J-energy.toml"
