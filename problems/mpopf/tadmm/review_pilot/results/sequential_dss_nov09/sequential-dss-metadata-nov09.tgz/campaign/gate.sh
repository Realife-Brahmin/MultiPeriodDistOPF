#!/usr/bin/env bash
set -euo pipefail
C=$1;P=problems/mpopf/tadmm/review_pilot;cd "$C/source";source "$C/campaign/env.sh"
sha256sum --check --quiet "$C/execution-source.sha256"
julia --startup-file=no --project="$P" "$P/validate_sequential_dss.jl"
date -u +%FT%TZ > "$C/SEQUENTIAL_GATE_VALIDATED"
