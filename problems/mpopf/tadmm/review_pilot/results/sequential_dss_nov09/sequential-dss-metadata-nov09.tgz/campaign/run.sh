#!/usr/bin/env bash
set -euo pipefail
C=$1;P=problems/mpopf/tadmm/review_pilot;cd "$C/source";source "$C/campaign/env.sh"
test -s "$C/SEQUENTIAL_GATE_VALIDATED"
sha256sum --check --quiet "$C/execution-source.sha256"
OLD=/home/aryan.jha/kamiak_jobs/tadmm_review_nov09_persistent_caps
for NAME in central cap30 cap10;do
 if [[ $NAME == central ]]; then
  CASE="$OLD/results/run_T24_primal_dual_31665889";SOL="$CASE/central_dispatch.jls"
 elif [[ $NAME == cap30 ]]; then
  CASE="$OLD/results/run_T24_primal_dual_31665887";SOL="$CASE/rho15000/endpoint.jls"
 else
  CASE="$OLD/results/run_T24_primal_dual_31665889";SOL="$CASE/rho15000/endpoint.jls"
 fi
 for EFF in model dss;do
  OUT="$C/results/$NAME-$EFF"
  julia --startup-file=no --project="$P" "$P/run_sequential_dss.jl" "$CASE/instance.jls" "$SOL" "$OUT" "$EFF" > "$C/logs/$NAME-$EFF.log" 2> "$C/logs/$NAME-$EFF.err"
  for F in "$OUT/"*.csv;do gzip "$F";done
 done
done
date -u +%FT%TZ > "$C/SEQUENTIAL_REPLAYS_RECORDED"
