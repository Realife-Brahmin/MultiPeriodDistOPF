export JULIA_DEPOT_PATH="/home/aryan.jha/kamiak_jobs/tadmm_review_nov09_persistent_caps/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov08_horizon_sweep/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_v2/julia-depot:/home/aryan.jha/kamiak_jobs/tree_ablation_oct20_campaign_v2/julia-depot"
export JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export PATH=/home/aryan.jha/opt/julia-1.12.4/bin:$PATH
