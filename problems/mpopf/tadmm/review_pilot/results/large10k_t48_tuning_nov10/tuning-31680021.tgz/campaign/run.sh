#!/usr/bin/env bash
set -euo pipefail
C=$1
CAP=$2
RHO=$3
[[ ${SLURM_JOB_NUM_NODES:?} == 1 ]]
export TADMM_RHO_POLICY=bootstrap_fixed TADMM_BOOTSTRAP_DECREASE=$4 TADMM_RHO_FLOOR=$5 TADMM_BOOTSTRAP_GATE=$6
export TADMM_RHO_PROVENANCE="Predeclared exploratory T48 tuning grid"
if [[ $CAP == exact ]]; then
 export TADMM_LOCAL_SOLVE_POLICY=exact
else
 export TADMM_LOCAL_SOLVE_POLICY=persistent_cap TADMM_CAP_ITERATIONS=$CAP TADMM_CAP_SCREEN=finite
fi
exec bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" 48 run primal_dual "$RHO" ma57 large10kC_1ph
