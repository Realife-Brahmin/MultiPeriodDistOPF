#!/usr/bin/env bash
set -euo pipefail
C=$1
POLICY=$2
[[ ${SLURM_JOB_NUM_NODES:?} == 1 ]]
test -s "$C/MED_SEQUENCE_GATE_VALIDATED"
export TADMM_RHO_POLICY=bootstrap_fixed TADMM_RHO_FLOOR=48
if [[ $POLICY == cap10 ]]; then
 export TADMM_LOCAL_SOLVE_POLICY=persistent_cap TADMM_CAP_ITERATIONS=10 TADMM_CAP_SCREEN=finite
else
 export TADMM_LOCAL_SOLVE_POLICY=exact
fi
exec bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" 48 run primal_dual 120000 ma57 large10kC_1ph
