#!/usr/bin/env bash
set -euo pipefail
C=$1;CAP=$2;test -s "$C/MED_SEQUENCE_GATE_VALIDATED"
[[ $SLURM_JOB_NUM_NODES == 1 ]]
export TADMM_CPU_MODEL_MATCH=6760P
export TADMM_RHO_POLICY=bootstrap_fixed TADMM_RHO_FLOOR=48
export TADMM_LOCAL_SOLVE_POLICY=persistent_cap TADMM_CAP_ITERATIONS=$CAP TADMM_CAP_SCREEN=finite
# make_model(local_window=false) forces exact policy for centralized.
# Centralized retains max_iter=3000 and must return solved, never iteration limit.
exec bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" 96 run primal_dual 20000 ma57 ieee2522C_1ph
