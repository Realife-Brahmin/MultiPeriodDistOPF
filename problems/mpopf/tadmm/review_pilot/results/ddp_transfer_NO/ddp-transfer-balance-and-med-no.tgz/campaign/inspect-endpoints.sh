#!/usr/bin/env bash
set -euo pipefail
C=/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_balance2
C5=/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_ddp_transfer_v2
REF=/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_accuracy_fix
cd "$C/source"
export PATH=/home/aryan.jha/opt/julia-1.12.4/bin:$PATH
export JULIA_DEPOT_PATH="$C/julia-depot:$REF/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_parallel/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_v2/julia-depot:/home/aryan.jha/kamiak_jobs/tree_ablation_oct20_campaign_v2/julia-depot"
export JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TADMM_LINEAR_SOLVER=ma57
export TADMM_IPOPT_OPTIONS="hsllib=$HOME/opt/hsl-private/install/ma57-3.11.3-metis/lib/libma57.so;linear_system_scaling=none;ma57_pivot_order=2"
sha256sum --check --quiet "$C/execution-source.sha256"
sha256sum --check --quiet "$C/input.sha256"
OUT="$C/endpoint-components-$SLURM_JOB_ID"
mkdir -p "$OUT"
sha256sum "$C/campaign/inspect_no_checkpoints.jl" "$0" > "$OUT/analysis-source.sha256"
julia --startup-file=no --project=problems/mpopf/tadmm/review_pilot "$C/campaign/inspect_no_checkpoints.jl" "$C/source" "$C5" "$C" "$OUT"
