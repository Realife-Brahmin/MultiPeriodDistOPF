#!/usr/bin/env bash
set -euo pipefail
C=$1; SYSTEM=$2; T=$3; RHO=$4; SOLVER=$5
test -s "$C/ANCHOR_GATE_VALIDATED"
export TADMM_RHO_POLICY=bootstrap_fixed TADMM_RHO_FLOOR=48 TADMM_LOCAL_SOLVE_POLICY=exact
exec bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" "$T" run primal_dual "$RHO" "$SOLVER" "$SYSTEM"
