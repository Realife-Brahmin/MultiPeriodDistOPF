#!/usr/bin/env bash
set -euo pipefail
C=$1; P=problems/mpopf/tadmm/review_pilot
cd "$C/source"
export JULIA_DEPOT_PATH="$C/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov08_horizon_sweep/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_accuracy_fix/julia-depot:/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_v2/julia-depot:/home/aryan.jha/kamiak_jobs/tree_ablation_oct20_campaign_v2/julia-depot"
export PATH=/home/aryan.jha/opt/julia-1.12.4/bin:$PATH
export JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export PROFILE_PERIODIC=1 OPENDSS_ZERO_LINE_C=1 TERMINAL_SOC_SOFT=0 DROP_ROOT_DERS=0
julia --startup-file=no --project="$P" problems/mpopf/spar_ddp/examples/power_system/export_ieee123c_data.jl ieee2522C_1ph 96 > "$C/campaign/export-med2522-T96.log" 2>&1
sha256sum problems/mpopf/spar_ddp/results/network_filterddp/network_data_large10kC_1ph_T24_periodic.jls problems/mpopf/spar_ddp/results/network_filterddp/network_data_ieee2522C_1ph_T96_periodic.jls > "$C/input.sha256"
for SOLVER in ma57 mumps; do
 export TADMM_LINEAR_SOLVER=$SOLVER
 if [[ $SOLVER == ma57 ]]; then
  export TADMM_IPOPT_OPTIONS="hsllib=$HOME/opt/hsl-private/install/ma57-3.11.3-metis/lib/libma57.so;linear_system_scaling=none;ma57_pivot_order=2"
 else export TADMM_IPOPT_OPTIONS=linear_system_scaling=none; fi
 julia --startup-file=no --project="$P" "$P/validate_stage_reuse.jl" > "$C/campaign/gate-$SOLVER.log" 2>&1
done
sha256sum --check --quiet "$C/execution-source.sha256"
date -u +%FT%TZ > "$C/ANCHOR_GATE_VALIDATED"
