#!/usr/bin/env bash
set -euo pipefail
C=$1; T=$2; RHO=$3
test -s "$C/MUMPS_FIXED_GATE_VALIDATED"
if [[ $T == 96 ]]; then
 test -s "$C/T48_VALIDATED"
fi
export TADMM_RHO_POLICY=bootstrap_fixed TADMM_RHO_FLOOR=48 TADMM_LOCAL_SOLVE_POLICY=exact
bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" "$T" run primal_dual "$RHO" mumps
if [[ $T == 48 ]]; then
 test -s "$C/results/run_T48_primal_dual_$SLURM_JOB_ID/SWEEP_VALIDATED"
 date -u +%FT%TZ > "$C/T48_VALIDATED"
fi
