using Pkg
Pkg.add(PackageSpec(name="SlurmClusterManager",version="1.1.0");preserve=Pkg.PRESERVE_ALL)
Pkg.precompile()
using JuMP,Ipopt,SlurmClusterManager
Pkg.status()
