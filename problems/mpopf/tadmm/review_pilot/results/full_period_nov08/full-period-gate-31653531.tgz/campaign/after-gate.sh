#!/usr/bin/env bash
set -euo pipefail
C=$1;T=$2;WARM=$3;RHO=$4
test -s "$C/results/gate_T96_primal_dual_31653531/FULL_PERIOD_GATE_VALIDATED"
cp "$C/results/gate_T96_primal_dual_31653531/FULL_PERIOD_GATE_VALIDATED" "$C/FULL_PERIOD_READY"
exec bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" "$T" run "$WARM" "$RHO"
