using Pkg
launcher=joinpath(dirname(Base.active_project()),"slurm")
Pkg.activate(launcher)
Pkg.add(PackageSpec(name="SlurmClusterManager",version="1.1.0");preserve=Pkg.PRESERVE_ALL)
Pkg.precompile()
using SlurmClusterManager
Pkg.status()
