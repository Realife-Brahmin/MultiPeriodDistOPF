#!/usr/bin/env bash
set -euo pipefail
C=/home/aryan.jha/kamiak_jobs/tadmm_review_nov08_full_period
export PYTHONPATH=/home/aryan.jha/kamiak_jobs/tadmm_review_nov07_v2/python-deps
sha256sum --check --quiet "$C/campaign/selection-source.sha256"
python3 "$C/campaign/choose_full_period_warm_start.py" "$C" 31653532 31653533 --submit
read -r J WARM < <(python3 -c 'import json,sys;r=json.load(open(sys.argv[1]));print(r["T96_job"],r["selected_warm_start"])' "$C/campaign/warm-start-selection.json")
AUDIT=$(sbatch --parsable --account=dubey --partition=kamiak --nodes=1 --ntasks=1 --cpus-per-task=1 --mem=8G --time=00:15:00 --dependency="afterany:$J" --job-name=tadmm-T96-energy-audit --output="$C/logs/audit-T96-%j.out" --error="$C/logs/audit-T96-%j.err" "$C/campaign/audit-T96.sh" "$C" "$J" "$WARM")
printf 'T96=%s\nT96_energy_audit=%s\n' "$J" "$AUDIT" >> "$C/campaign/submissions.txt"
export TADMM_AUDIT_VALIDATED_ONLY=1 JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
for CASE in "$C/results/run_T48_primal_31653532" "$C/results/run_T48_primal_dual_31653533";do
 if [[ -s "$CASE/SWEEP_VALIDATED" ]];then
  /home/aryan.jha/opt/julia-1.12.4/bin/julia --startup-file=no "$C/source/problems/mpopf/tadmm/review_pilot/audit_sweep_energy.jl" "$CASE" "$C/campaign/$(basename "$CASE")-energy.toml"
 fi
done
