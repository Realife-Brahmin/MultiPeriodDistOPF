#!/usr/bin/env bash
set -euo pipefail
C=$1;J=$2;WARM=$3
CASE="$C/results/run_T96_${WARM}_$J"
test -s "$CASE/SWEEP_VALIDATED"
export TADMM_AUDIT_VALIDATED_ONLY=1 JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
/home/aryan.jha/opt/julia-1.12.4/bin/julia --startup-file=no "$C/source/problems/mpopf/tadmm/review_pilot/audit_sweep_energy.jl" "$CASE" "$C/campaign/T96-$J-energy.toml"
