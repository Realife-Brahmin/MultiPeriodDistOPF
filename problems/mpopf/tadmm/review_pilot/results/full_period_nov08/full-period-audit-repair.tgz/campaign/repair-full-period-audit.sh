#!/usr/bin/env bash
set -euo pipefail
C=/home/aryan.jha/kamiak_jobs/tadmm_review_nov08_full_period
export TADMM_AUDIT_LAYOUT="$C/source/problems/mpopf/spar_ddp/examples/power_system/control_layout.jl"
export TADMM_AUDIT_VALIDATED_ONLY=1 JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
sha256sum "$C/campaign/audit_sweep_energy.jl" "$TADMM_AUDIT_LAYOUT" > "$C/campaign/audit-repair-$SLURM_JOB_ID.sha256"
for CASE in run_T48_primal_31653532 run_T48_primal_dual_31653533 run_T96_primal_dual_31653593;do
 test -s "$C/results/$CASE/SWEEP_VALIDATED"
 /home/aryan.jha/opt/julia-1.12.4/bin/julia --startup-file=no "$C/campaign/audit_sweep_energy.jl" "$C/results/$CASE" "$C/campaign/$CASE-energy.toml"
done
