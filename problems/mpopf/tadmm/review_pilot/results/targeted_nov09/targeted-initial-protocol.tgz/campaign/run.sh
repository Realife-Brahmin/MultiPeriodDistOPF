#!/usr/bin/env bash
set -euo pipefail
C=$1;ARM=$2;test -s "$C/RECOVERY_GATE_VALIDATED"
if [[ $ARM == retry ]];then
 export TADMM_RHO_POLICY=legacy_phase TADMM_LOCAL_SOLVE_POLICY=warm_retry TADMM_WARM_RETRY_LIMIT=20
elif [[ $ARM == fixed ]];then
 export TADMM_RHO_POLICY=bootstrap_fixed TADMM_RHO_FLOOR=48 TADMM_LOCAL_SOLVE_POLICY=exact
else exit 2;fi
exec bash "$C/source/problems/mpopf/tadmm/review_pilot/kamiak_full_period.sh" "$C" 48 run primal_dual 120000 ma57
